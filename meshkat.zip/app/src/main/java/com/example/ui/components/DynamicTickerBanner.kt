package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TickerEntity
import com.example.ui.theme.MeshkatPrimary
import com.example.ui.theme.MeshkatSecondary

@Composable
fun DynamicTickerBanner(
    ticker: TickerEntity?,
    onBannerClick: () -> Unit = {}
) {
    if (ticker == null || !ticker.isActive || ticker.messageText.isBlank()) {
        return
    }

    val scrollState = rememberScrollState()
    var isPaused by remember { mutableStateOf(false) }

    // Auto-scroll loop for ticker
    LaunchedEffect(ticker.messageText, isPaused) {
        if (!isPaused) {
            while (true) {
                val maxScroll = scrollState.maxValue
                if (maxScroll > 0) {
                    val current = scrollState.value
                    val next = if (current >= maxScroll) 0 else current + 2
                    scrollState.scrollTo(next)
                }
                kotlinx.coroutines.delay(ticker.speedMs.toLong().coerceAtLeast(15L))
            }
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("dynamic_ticker_banner")
            .clickable {
                isPaused = !isPaused
                onBannerClick()
            },
        color = MeshkatPrimary,
        shadowElevation = 3.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ticker badge
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(MeshkatSecondary)
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Campaign,
                        contentDescription = "اعلان متحرک",
                        tint = Color(0xFF241C00),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "نوار اطلاع‌رسانی",
                        color = Color(0xFF241C00),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Scrolling text container
            Box(
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(scrollState, enabled = false)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = ticker.messageText,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                    // Repeating copy so it flows continuously
                    Text(
                        text = "   ✦   ${ticker.messageText}",
                        color = Color(0xFFFFE082),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )
                }
            }
        }
    }
}
