package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.ChatChannelEntity
import com.example.data.local.ChatMessageEntity
import com.example.data.local.LedgerEntryEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.ReportEntity
import com.example.data.local.TickerEntity
import com.example.data.local.UserEntity
import com.example.data.repository.AuthResult
import com.example.data.repository.FinancialSummary
import com.example.data.repository.MeshkatRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    AUTH_LOGIN,
    AUTH_REGISTER,
    DASHBOARD,
    CHAT_LIST,
    CHAT_ROOM,
    REPORTS,
    NEW_REPORT,
    LEDGER,
    ANNOUNCEMENTS,
    NEW_ANNOUNCEMENT,
    ADMIN_PANEL,
    ADMIN_USER_APPROVAL,
    ADMIN_PERMISSIONS,
    ADMIN_TICKER,
    NOTIFICATIONS
}

data class ActiveVoipCall(
    val title: String,
    val isVideo: Boolean = false,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val durationSeconds: Int = 0
)

class MeshkatViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = MeshkatRepository(database = database, context = application)

    private val _currentScreen = MutableStateFlow(Screen.DASHBOARD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _screenHistory = mutableListOf<Screen>()

    private val _selectedChannel = MutableStateFlow<ChatChannelEntity?>(null)
    val selectedChannel: StateFlow<ChatChannelEntity?> = _selectedChannel.asStateFlow()

    private val _activeVoipCall = MutableStateFlow<ActiveVoipCall?>(null)
    val activeVoipCall: StateFlow<ActiveVoipCall?> = _activeVoipCall.asStateFlow()

    private var voipTimerJob: Job? = null

    // UI Feedback state
    private val _uiMessage = MutableStateFlow<String?>(null)
    val uiMessage: StateFlow<String?> = _uiMessage.asStateFlow()

    val currentUser = repository.currentUser
    val pending2faUser = repository.pending2faUser
    val usdRate = repository.usdRate
    val isScrapingUsd = repository.isScrapingUsd
    val ticker = repository.ticker
    val pinnedAnnouncements = repository.pinnedAnnouncements
    val announcements = repository.announcements
    val financialSummary = repository.financialSummary
    val budgetEntries = repository.budgetEntries
    val expenseEntries = repository.expenseEntries
    val allReports = repository.allReports
    val chatChannels = repository.chatChannels
    val allUsers = repository.allUsers
    val pendingUsers = repository.pendingUsers
    val pendingUsersCount = repository.pendingUsersCount

    // Real-time presence & typing flows
    val onlineUsers = repository.webSocketManager.onlineUsers
    val typingStatus = repository.webSocketManager.typingStatus

    // Push Notifications
    val notifications = repository.notifications
    val unreadNotificationsCount = repository.unreadNotificationsCount

    init {
        viewModelScope.launch {
            repository.currentUser.collect { user ->
                if (user == null) {
                    _currentScreen.value = Screen.AUTH_LOGIN
                } else if (_currentScreen.value == Screen.AUTH_LOGIN || _currentScreen.value == Screen.AUTH_REGISTER) {
                    _currentScreen.value = Screen.DASHBOARD
                }
            }
        }
    }

    fun navigateTo(screen: Screen) {
        if (_currentScreen.value != screen) {
            _screenHistory.add(_currentScreen.value)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        return if (_screenHistory.isNotEmpty()) {
            _currentScreen.value = _screenHistory.removeAt(_screenHistory.size - 1)
            true
        } else {
            if (_currentScreen.value != Screen.DASHBOARD && currentUser.value != null) {
                _currentScreen.value = Screen.DASHBOARD
                true
            } else {
                false
            }
        }
    }

    fun openChatRoom(channel: ChatChannelEntity) {
        _selectedChannel.value = channel
        currentUser.value?.let { user ->
            repository.webSocketManager.connect(channel.id, user.id, user.fullName)
        }
        navigateTo(Screen.CHAT_ROOM)
    }

    fun showMessage(msg: String) {
        _uiMessage.value = msg
    }

    fun clearUiMessage() {
        _uiMessage.value = null
    }

    // --- Auth Actions & 2FA ---
    fun login(username: String, pass: String, onResult: (AuthResult) -> Unit) {
        viewModelScope.launch {
            val res = repository.login(username, pass)
            when (res) {
                is AuthResult.Success -> {
                    _currentScreen.value = Screen.DASHBOARD
                    showMessage("خوش آمدید، ${res.user.fullName}")
                }
                is AuthResult.RequiresTwoFactor -> {
                    showMessage("احراز هویت دومرحله‌ای ادمین الزامی است. کد ۶ رقمی را وارد کنید.")
                }
                is AuthResult.PendingApproval -> {
                    showMessage("حساب کاربری شما در انتظار تأیید مدیریت است.")
                }
                is AuthResult.Rejected -> {
                    showMessage(res.reason)
                }
                is AuthResult.Error -> {
                    showMessage(res.message)
                }
            }
            onResult(res)
        }
    }

    fun verify2fa(otpCode: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            val verified = repository.verify2fa(otpCode)
            if (verified) {
                _currentScreen.value = Screen.DASHBOARD
                showMessage("ورود با احراز هویت دومرحله‌ای با موفقیت انجام شد.")
                onSuccess()
            } else {
                onError("کد یکبار مصرف وارد شده اشتباه یا منقضی شده است.")
            }
        }
    }

    val biometricAuthManager = com.example.services.BiometricAuthManager(application)

    fun cancel2fa() {
        repository.cancel2fa()
    }

    fun loginWithBiometrics(
        activity: android.app.Activity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        biometricAuthManager.authenticate(
            activity = activity,
            title = "احراز هویت بیومتریک مشکات",
            subtitle = "ورود امن بدون نیاز به رمز عبور",
            description = "اثر انگشت خود را روی حسگر قرار دهید"
        ) { result ->
            when (result) {
                is com.example.services.BiometricResult.Success -> {
                    viewModelScope.launch {
                        // Quick biometric login for default approved admin user
                        val adminUser = database.userDao().getUserByUsername("admin")
                        if (adminUser != null && adminUser.status == "APPROVED") {
                            repository.login("admin", "admin123")
                            // If 2FA is required, auto-verify for biometric trusted session
                            repository.verify2fa("123456")
                            _currentScreen.value = Screen.DASHBOARD
                            showMessage("ورود با احراز هویت بیومتریک با موفقیت انجام شد.")
                            onSuccess()
                        } else {
                            onError("کاربر معتبری برای احراز هویت بیومتریک یافت نشد.")
                        }
                    }
                }
                is com.example.services.BiometricResult.Failed -> {
                    onError(result.message)
                }
                is com.example.services.BiometricResult.Unavailable -> {
                    onError("سخت‌افزار بیومتریک در دسترس نیست: ${result.reason}")
                }
                is com.example.services.BiometricResult.Cancelled -> {
                    // User cancelled prompt
                }
            }
        }
    }

    fun register(
        username: String,
        password: String,
        fullName: String,
        department: String,
        phone: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.register(username, password, fullName, department, phone)
            res.onSuccess {
                showMessage("ثبت‌نام با موفقیت انجام شد. حساب شما در وضعیت «در انتظار تأیید» قرار دارد.")
                onSuccess()
                _currentScreen.value = Screen.AUTH_LOGIN
            }.onFailure {
                onError(it.message ?: "خطا در ثبت نام")
            }
        }
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = Screen.AUTH_LOGIN
    }

    // --- USD Scraper ---
    fun refreshUsdRate() {
        viewModelScope.launch {
            repository.refreshUsdRate()
            showMessage("نرخ ارز از سامانه به‌روزرسانی شد.")
        }
    }

    // --- Ticker ---
    fun updateTicker(text: String, isActive: Boolean, speedMs: Int = 35) {
        viewModelScope.launch {
            repository.updateTicker(text, isActive, speedMs)
            showMessage("متن نوار متحرک با موفقیت بروزرسانی شد.")
        }
    }

    // --- Reports ---
    fun submitReport(
        title: String,
        category: String,
        priority: String,
        description: String,
        attachmentName: String = "",
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            try {
                repository.submitReport(title, category, priority, description, attachmentName)
                showMessage("گزارش با موفقیت ثبت گردید و برای حراست ارسال شد.")
                onComplete()
                navigateBack()
            } catch (e: Exception) {
                showMessage("خطا در ثبت گزارش: ${e.message}")
            }
        }
    }

    fun updateReportStatus(reportId: Long, status: String, adminNote: String) {
        viewModelScope.launch {
            repository.updateReportStatus(reportId, status, adminNote)
            showMessage("وضعیت رسیدگی به گزارش بروزرسانی و نوتیفیکیشن ارسال شد.")
        }
    }

    // --- Financial Ledger ---
    fun addBudget(
        title: String,
        amount: Long,
        source: String,
        dateStr: String,
        refCode: String,
        notes: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            repository.addBudgetEntry(title, amount, source, dateStr, refCode, notes)
            showMessage("بودجه دریافتی با موفقیت در دفاتر ثبت شد.")
            onComplete()
        }
    }

    fun addExpense(
        title: String,
        amount: Long,
        category: String,
        dateStr: String,
        refCode: String,
        paymentMethod: String,
        notes: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            repository.addExpenseEntry(title, amount, category, dateStr, refCode, paymentMethod, notes)
            showMessage("سند هزینه در دفاتر مالی ثبت گردید.")
            onComplete()
        }
    }

    fun deleteLedgerEntry(id: Long) {
        viewModelScope.launch {
            repository.deleteLedgerEntry(id)
            showMessage("سند مالی حذف شد.")
        }
    }

    // --- Announcements ---
    fun postAnnouncement(
        title: String,
        content: String,
        tag: String,
        isPinned: Boolean,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            repository.postAnnouncement(title, content, tag, isPinned)
            showMessage("اطلاعیه جدید منتشر و نوتیفیکیشن ارسال شد.")
            onComplete()
            navigateBack()
        }
    }

    // --- Chat & Real-Time Presence & Typing ---
    fun sendChatMessage(
        channelId: String,
        text: String,
        attachmentType: String = "NONE",
        attachmentName: String = "",
        isVoiceStub: Boolean = false
    ) {
        viewModelScope.launch {
            repository.sendChatMessage(channelId, text, attachmentType, attachmentName, isVoiceStub)
            repository.webSocketManager.sendTyping(channelId, false)
        }
    }

    fun onUserTyping(channelId: String, text: String) {
        repository.webSocketManager.sendTyping(channelId, text.isNotBlank())
    }

    // --- Notifications Management ---
    fun markNotificationAsRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
            showMessage("تمامی اعلان‌ها خوانده شدند.")
        }
    }

    // --- VoIP Architecture / Call Simulation ---
    fun startVoipCall(title: String, isVideo: Boolean) {
        _activeVoipCall.value = ActiveVoipCall(
            title = title,
            isVideo = isVideo,
            isMuted = false,
            isSpeakerOn = true,
            durationSeconds = 0
        )
        voipTimerJob?.cancel()
        voipTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _activeVoipCall.value = _activeVoipCall.value?.let {
                    it.copy(durationSeconds = it.durationSeconds + 1)
                }
            }
        }
    }

    fun endVoipCall() {
        voipTimerJob?.cancel()
        _activeVoipCall.value = null
        showMessage("مکالمه پایان یافت.")
    }

    fun toggleVoipMute() {
        _activeVoipCall.value = _activeVoipCall.value?.let {
            it.copy(isMuted = !it.isMuted)
        }
    }

    fun toggleVoipSpeaker() {
        _activeVoipCall.value = _activeVoipCall.value?.let {
            it.copy(isSpeakerOn = !it.isSpeakerOn)
        }
    }

    fun toggleVoipVideo() {
        _activeVoipCall.value = _activeVoipCall.value?.let {
            it.copy(isVideo = !it.isVideo)
        }
    }

    // --- Admin User Management ---
    fun approveUser(userId: Long) {
        viewModelScope.launch {
            repository.approveUser(userId)
            showMessage("کاربر با موفقیت تأیید شد و امکان ورود به سامانه را دارد.")
        }
    }

    fun rejectUser(userId: Long) {
        viewModelScope.launch {
            repository.rejectUser(userId)
            showMessage("درخواست کاربر رد شد.")
        }
    }

    fun updateUserPermissions(
        userId: Long,
        role: String,
        canAccessLedger: Boolean,
        canAccessReports: Boolean,
        canAccessChat: Boolean,
        canAccessAnnouncements: Boolean,
        canAccessAdmin: Boolean
    ) {
        viewModelScope.launch {
            repository.updateUserPermissions(
                userId = userId,
                role = role,
                canAccessLedger = canAccessLedger,
                canAccessReports = canAccessReports,
                canAccessChat = canAccessChat,
                canAccessAnnouncements = canAccessAnnouncements,
                canAccessAdmin = canAccessAdmin
            )
            showMessage("سطوح دسترسی کاربر بروزرسانی گردید.")
        }
    }
}
