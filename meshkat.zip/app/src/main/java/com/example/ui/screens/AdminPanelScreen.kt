package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HowToReg
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.UserEntity
import com.example.ui.MeshkatViewModel
import com.example.ui.theme.MeshkatPrimary
import com.example.ui.theme.MeshkatSecondary
import com.example.ui.theme.StatusApproved
import com.example.ui.theme.StatusPending
import com.example.ui.theme.StatusRejected

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(viewModel: MeshkatViewModel) {
    val pendingUsers by viewModel.pendingUsers.collectAsState(initial = emptyList())
    val allUsers by viewModel.allUsers.collectAsState(initial = emptyList())
    val ticker by viewModel.ticker.collectAsState(initial = null)

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var selectedUserForEdit by remember { mutableStateOf<UserEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مرکز مدیریت و نظارت عالی مشکات", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MeshkatPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.testTag("admin_panel_screen")
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MeshkatPrimary
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("تأیید ثبت‌نام‌ها", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            if (pendingUsers.isNotEmpty()) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(shape = CircleShape, color = StatusPending) {
                                    Text(
                                        text = pendingUsers.size.toString(),
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    },
                    modifier = Modifier.testTag("tab_admin_approvals")
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("کاربران و سطوح دسترسی", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_admin_rbac")
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = { Text("مدیریت نوار متحرک", fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("tab_admin_ticker")
                )
            }

            when (selectedTabIndex) {
                0 -> {
                    // TAB 0: USER APPROVAL GATE
                    if (pendingUsers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.HowToReg,
                                    contentDescription = null,
                                    tint = StatusApproved,
                                    modifier = Modifier.size(56.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "هیچ کاربری در انتظار تأیید نیست",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "ثبت‌نام‌های جدید بلافاصله در این بخش جهت تأیید ظاهر خواهند شد.",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(pendingUsers, key = { it.id }) { user ->
                                PendingUserCard(
                                    user = user,
                                    onApprove = { viewModel.approveUser(user.id) },
                                    onReject = { viewModel.rejectUser(user.id) }
                                )
                            }
                        }
                    }
                }

                1 -> {
                    // TAB 1: USERS & RBAC MATRIX
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(allUsers, key = { it.id }) { user ->
                            UserRbacCard(
                                user = user,
                                onEditPermissions = { selectedUserForEdit = user }
                            )
                        }
                    }
                }

                2 -> {
                    // TAB 2: TICKER MANAGER
                    ticker?.let { currentTicker ->
                        TickerManagerTab(
                            ticker = currentTicker,
                            onSave = { newText, isActive, speed ->
                                viewModel.updateTicker(newText, isActive, speed)
                            }
                        )
                    }
                }
            }
        }
    }

    selectedUserForEdit?.let { user ->
        EditUserPermissionsDialog(
            user = user,
            onDismiss = { selectedUserForEdit = null },
            onSave = { role, ledger, reports, chat, announcements, admin ->
                viewModel.updateUserPermissions(
                    userId = user.id,
                    role = role,
                    canAccessLedger = ledger,
                    canAccessReports = reports,
                    canAccessChat = chat,
                    canAccessAnnouncements = announcements,
                    canAccessAdmin = admin
                )
                selectedUserForEdit = null
            }
        )
    }
}

@Composable
fun PendingUserCard(
    user: UserEntity,
    onApprove: () -> Unit,
    onReject: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("pending_user_${user.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(StatusPending.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = StatusPending)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(text = user.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = "نام کاربری: @${user.username}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = StatusPending.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = "در انتظار تأیید",
                        color = StatusPending,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "واحد سازمانی: ${user.department} • همراه: ${user.phoneNumber}",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Action Buttons: Approve / Reject
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusApproved),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("btn_approve_user_${user.id}")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("تأیید عضویت", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = onReject,
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRejected),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("رد درخواست", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun UserRbacCard(
    user: UserEntity,
    onEditPermissions: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(MeshkatPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = user.fullName.take(1),
                            color = MeshkatPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(text = user.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(text = "${user.department} • نقش: ${user.role}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                IconButton(onClick = onEditPermissions) {
                    Icon(Icons.Default.Edit, contentDescription = "ویرایش دسترسی‌ها", tint = MeshkatPrimary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Permission badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                PermissionBadge(name = "مالی", granted = user.canAccessLedger)
                PermissionBadge(name = "گزارشات", granted = user.canAccessReports)
                PermissionBadge(name = "چت", granted = user.canAccessChat)
                PermissionBadge(name = "اطلاعیه", granted = user.canAccessAnnouncements)
                PermissionBadge(name = "ادمین", granted = user.canAccessAdmin)
            }
        }
    }
}

@Composable
fun PermissionBadge(name: String, granted: Boolean) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (granted) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
    ) {
        Text(
            text = "$name ${if (granted) "✓" else "✕"}",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (granted) Color(0xFF2E7D32) else Color(0xFFC62828),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun TickerManagerTab(
    ticker: com.example.data.local.TickerEntity,
    onSave: (newText: String, isActive: Boolean, speed: Int) -> Unit
) {
    var text by remember { mutableStateOf(ticker.messageText) }
    var isActive by remember { mutableStateOf(ticker.isActive) }
    var speed by remember { mutableIntStateOf(ticker.speedMs) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Campaign, contentDescription = null, tint = MeshkatPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "مدیریت نوار اعلان متحرک (Dynamic Ticker)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("متن نوار متحرک بالای برنامه") },
                    placeholder = { Text("متن اخبار فوری، اطلاعیه‌های لحظه‌ای و پیام‌های سازمانی...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("admin_ticker_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "فعال‌سازی نمایش نوار متحرک", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Text(text = "در صورت غیرفعال بودن، نوار از بالای برنامه پنهان می‌شود", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Switch(
                        checked = isActive,
                        onCheckedChange = { isActive = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = MeshkatPrimary)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onSave(text.trim(), isActive, speed) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("btn_save_ticker"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
                ) {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ذخیره و اعمال بلادرنگ بر روی برنامه", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun EditUserPermissionsDialog(
    user: UserEntity,
    onDismiss: () -> Unit,
    onSave: (role: String, ledger: Boolean, reports: Boolean, chat: Boolean, announcements: Boolean, admin: Boolean) -> Unit
) {
    var role by remember { mutableStateOf(user.role) }
    var ledger by remember { mutableStateOf(user.canAccessLedger) }
    var reports by remember { mutableStateOf(user.canAccessReports) }
    var chat by remember { mutableStateOf(user.canAccessChat) }
    var announcements by remember { mutableStateOf(user.canAccessAnnouncements) }
    var admin by remember { mutableStateOf(user.canAccessAdmin) }

    val roles = listOf("ADMIN", "MANAGER", "OPERATOR", "USER")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعیین سطح دسترسی: ${user.fullName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "انتخاب نقش کاربری (RBAC):", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    roles.forEach { r ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (role == r) MeshkatPrimary else Color(0xFFE0E0E0),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { role = r }
                        ) {
                            Text(
                                text = r,
                                color = if (role == r) Color.White else Color.Black,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 6.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(text = "مجوز ورود به بخش‌ها:", fontWeight = FontWeight.Bold, fontSize = 12.sp)

                PermissionSwitchRow(title = "دسترسی به امور مالی و بودجه", checked = ledger, onCheckedChange = { ledger = it })
                PermissionSwitchRow(title = "دسترسی به گزارشات امنیتی", checked = reports, onCheckedChange = { reports = it })
                PermissionSwitchRow(title = "دسترسی به چت و ارتباطات", checked = chat, onCheckedChange = { chat = it })
                PermissionSwitchRow(title = "دسترسی به تابلوی اطلاعیه", checked = announcements, onCheckedChange = { announcements = it })
                PermissionSwitchRow(title = "دسترسی به پنل مدیریت کل", checked = admin, onCheckedChange = { admin = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(role, ledger, reports, chat, announcements, admin) },
                colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
            ) {
                Text("ذخیره مجوزها")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun PermissionSwitchRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, fontSize = 12.sp)
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = MeshkatPrimary)
        )
    }
}
