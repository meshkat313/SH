package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AuthResult
import com.example.ui.MeshkatViewModel
import com.example.ui.theme.MeshkatPrimary
import com.example.ui.theme.MeshkatSecondary
import com.example.ui.theme.StatusApproved
import com.example.ui.theme.StatusPending
import kotlinx.coroutines.delay

@Composable
fun AuthScreen(viewModel: MeshkatViewModel) {
    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var loginUsername by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }

    // Register fields
    var regFullName by remember { mutableStateOf("") }
    var regDepartment by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regUsername by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }

    // 2FA state
    val pending2faUser by viewModel.pending2faUser.collectAsState()
    var otpInput by remember { mutableStateOf("") }
    var otpTimerSeconds by remember { mutableIntStateOf(60) }

    var errorMessage by remember { mutableStateOf<String?>(null) }
    var pendingNoticeUser by remember { mutableStateOf<String?>(null) }
    var successNotice by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()

    // 2FA Timer Countdown
    LaunchedEffect(pending2faUser) {
        if (pending2faUser != null) {
            otpTimerSeconds = 60
            while (otpTimerSeconds > 0) {
                delay(1000)
                otpTimerSeconds--
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF071C15),
                        Color(0xFF0F4C3A),
                        Color(0xFF13201C)
                    )
                )
            )
            .testTag("auth_screen")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 24.dp, vertical = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(14.dp))

            // App Brand Emblem
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(MeshkatSecondary.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "مشکات",
                    tint = MeshkatSecondary,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = "سامانه جامع مشکات",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Text(
                text = "پرتال امنیتی، عملیاتی و امور مالی سازمان",
                fontSize = 12.sp,
                color = Color.White.copy(alpha = 0.8f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Check if 2FA Challenge is Active for Admin User
            if (pending2faUser != null) {
                val (adminUser, tempOtp) = pending2faUser!!

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_2fa_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFD4AF37).copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = Color(0xFFB8860B),
                                modifier = Modifier.size(32.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "احراز هویت دومرحله‌ای ادمین (2FA)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "مدیر ارشد گرامی (${adminUser.fullName})، به منظور برقراری امنیت دسترسی به پنل مدیریت، کد ۶ رقمی را وارد فرمایید.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )

                        // Demo OTP hint badge
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MeshkatSecondary.copy(alpha = 0.15f),
                            modifier = Modifier.clickable { otpInput = tempOtp }
                        ) {
                            Text(
                                text = "کد یکبار مصرف امنیتی: $tempOtp (جهت تست کلیک کنید)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF8B6508),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { if (it.length <= 6) otpInput = it.filter { ch -> ch.isDigit() } },
                            label = { Text("کد ۶ رقمی تأیید") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("input_2fa_otp"),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Countdown / Resend
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (otpTimerSeconds > 0) "اعتبار کد: $otpTimerSeconds ثانیه" else "کد منقضی شد",
                                fontSize = 11.sp,
                                color = if (otpTimerSeconds > 0) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFFC62828)
                            )

                            if (otpTimerSeconds == 0) {
                                TextButton(onClick = { otpTimerSeconds = 60 }) {
                                    Text("ارسال مجدد کد", fontSize = 11.sp)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                if (otpInput.length == 6) {
                                    viewModel.verify2fa(
                                        otpCode = otpInput,
                                        onSuccess = {},
                                        onError = { errorMessage = it }
                                    )
                                } else {
                                    errorMessage = "لطفاً کد ۶ رقمی کامل را وارد نمایید."
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("btn_verify_2fa"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
                        ) {
                            Text("تأیید هویت و ورود به پنل مدیریت", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        TextButton(onClick = { viewModel.cancel2fa() }) {
                            Text("انصراف و بازگشت به صفحه ورود", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                // Main Auth Card Container (Login / Register Tabs)
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        // Tabs
                        TabRow(
                            selectedTabIndex = selectedTabIndex,
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            contentColor = MeshkatPrimary,
                            modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        ) {
                            Tab(
                                selected = selectedTabIndex == 0,
                                onClick = {
                                    selectedTabIndex = 0
                                    errorMessage = null
                                    pendingNoticeUser = null
                                },
                                text = { Text("ورود به سامانه", fontWeight = FontWeight.Bold) },
                                modifier = Modifier.testTag("tab_login")
                            )
                            Tab(
                                selected = selectedTabIndex == 1,
                                onClick = {
                                    selectedTabIndex = 1
                                    errorMessage = null
                                    pendingNoticeUser = null
                                },
                                text = { Text("ثبت‌نام پرسنل", fontWeight = FontWeight.Bold) },
                                modifier = Modifier.testTag("tab_register")
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Pending Notice Box (Comprehensive State Handling)
                        AnimatedVisibility(visible = pendingNoticeUser != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 14.dp)
                                    .testTag("pending_approval_notice"),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color(0xFFFFF3CD)
                                )
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.LockClock,
                                            contentDescription = null,
                                            tint = StatusPending,
                                            modifier = Modifier.size(24.dp)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = "قفل امنیتی: در انتظار تأیید مدیریت (Pending Approval)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF664D03)
                                            )
                                            Text(
                                                text = "کاربر گرامی (${pendingNoticeUser})، مشخصات شما ثبت شده است اما به علت الزامات حفاظتی مشکات، ورود تا زمان بررسی و تأیید ادمین در پنل نظارت مسدود است.",
                                                fontSize = 11.sp,
                                                color = Color(0xFF664D03)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "پشتیبانی ستادی: ۰۲۱-۸۸۴۵۰۰۰۰",
                                            fontSize = 10.sp,
                                            color = Color(0xFF664D03)
                                        )

                                        OutlinedButton(
                                            onClick = {
                                                // Re-check status
                                                viewModel.login(loginUsername, loginPassword) { res ->
                                                    if (res is AuthResult.PendingApproval) {
                                                        viewModel.showMessage("وضعیت همچنان «در انتظار بررسی» است.")
                                                    }
                                                }
                                            },
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("بررسی مجدد وضعیت", fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }

                        // Success Notice
                        AnimatedVisibility(visible = successNotice != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 14.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFD1E7DD))
                            ) {
                                Text(
                                    text = successNotice.orEmpty(),
                                    color = Color(0xFF0F5132),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        // Error Message
                        AnimatedVisibility(visible = errorMessage != null) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 14.dp),
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8D7DA))
                            ) {
                                Text(
                                    text = errorMessage.orEmpty(),
                                    color = Color(0xFF842029),
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }

                        if (selectedTabIndex == 0) {
                            // --- LOGIN TAB ---
                            OutlinedTextField(
                                value = loginUsername,
                                onValueChange = { loginUsername = it },
                                label = { Text("نام کاربری") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Person, contentDescription = null)
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_login_username"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = loginPassword,
                                onValueChange = { loginPassword = it },
                                label = { Text("رمز عبور") },
                                leadingIcon = {
                                    Icon(imageVector = Icons.Default.Lock, contentDescription = null)
                                },
                                trailingIcon = {
                                    IconButton(onClick = { showPassword = !showPassword }) {
                                        Icon(
                                            imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = null
                                        )
                                    }
                                },
                                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_login_password"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = {
                                    if (loginUsername.isBlank() || loginPassword.isBlank()) {
                                        errorMessage = "لطفاً نام کاربری و رمز عبور را وارد فرمایید."
                                        return@Button
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    pendingNoticeUser = null
                                    viewModel.login(loginUsername, loginPassword) { result ->
                                        isLoading = false
                                        when (result) {
                                            is AuthResult.PendingApproval -> {
                                                pendingNoticeUser = result.user.fullName
                                            }
                                            is AuthResult.RequiresTwoFactor -> {
                                                // 2FA modal handled automatically by state
                                            }
                                            is AuthResult.Rejected -> {
                                                errorMessage = result.reason
                                            }
                                            is AuthResult.Error -> {
                                                errorMessage = result.message
                                            }
                                            is AuthResult.Success -> {
                                            }
                                        }
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("btn_submit_login"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(22.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text("ورود به سامانه مشکات", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            val localCtx = androidx.compose.ui.platform.LocalContext.current
                            OutlinedButton(
                                onClick = {
                                    val activity = localCtx as? android.app.Activity
                                    if (activity != null) {
                                        errorMessage = null
                                        pendingNoticeUser = null
                                        viewModel.loginWithBiometrics(
                                            activity = activity,
                                            onSuccess = {},
                                            onError = { errorMessage = it }
                                        )
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("btn_biometric_login"),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = "احراز هویت بیومتریک",
                                    tint = MeshkatPrimary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ورود با اثر انگشت / تشخیص چهره (بیومتریک)",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MeshkatPrimary
                                )
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Quick demo logins for emulator evaluation
                            Text(
                                text = "ورود سریع آزمایشی (جهت تست و ارزیابی):",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MeshkatPrimary.copy(alpha = 0.1f),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            loginUsername = "admin"
                                            loginPassword = "admin123"
                                            pendingNoticeUser = null
                                            errorMessage = null
                                        }
                                        .testTag("chip_login_admin")
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = "مدیر ارشد (2FA)",
                                            fontSize = 11.sp,
                                            color = MeshkatPrimary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "admin / admin123",
                                            fontSize = 9.sp,
                                            color = MeshkatPrimary
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = StatusPending.copy(alpha = 0.12f),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            loginUsername = "reza_ahmadi"
                                            loginPassword = "user123"
                                            pendingNoticeUser = null
                                            errorMessage = null
                                        }
                                        .testTag("chip_login_pending")
                                ) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.padding(vertical = 8.dp)
                                    ) {
                                        Text(
                                            text = "کاربر مسدود (Pending)",
                                            fontSize = 11.sp,
                                            color = StatusPending,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "reza / user123",
                                            fontSize = 9.sp,
                                            color = StatusPending
                                        )
                                    }
                                }
                            }

                        } else {
                            // --- REGISTER TAB ---
                            OutlinedTextField(
                                value = regFullName,
                                onValueChange = { regFullName = it },
                                label = { Text("نام و نام خانوادگی") },
                                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_reg_fullname"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = regDepartment,
                                onValueChange = { regDepartment = it },
                                label = { Text("واحد سازمانی / معاونت") },
                                leadingIcon = { Icon(Icons.Default.Business, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_reg_department"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = regPhone,
                                onValueChange = { regPhone = it },
                                label = { Text("شماره همراه") },
                                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_reg_phone"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = regUsername,
                                onValueChange = { regUsername = it },
                                label = { Text("نام کاربری دلخواه") },
                                leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_reg_username"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = regPassword,
                                onValueChange = { regPassword = it },
                                label = { Text("رمز عبور") },
                                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                                visualTransformation = PasswordVisualTransformation(),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("input_reg_password"),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Strict Security Policy Note
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFFFF8E1)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = Color(0xFFF57F17),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "پروتکل امنیتی: پس از ثبت‌نام، حساب شما در وضعیت «Pending» قفل می‌گردد و ورود تنها پس از تأیید فیزیکی/سیستمی توسط ادمین در پنل مدیریت میسر خواهد بود.",
                                        fontSize = 11.sp,
                                        color = Color(0xFF795548),
                                        lineHeight = 16.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    if (regFullName.isBlank() || regUsername.isBlank() || regPassword.isBlank()) {
                                        errorMessage = "لطفاً تمامی فیلدهای الزامی را تکمیل کنید."
                                        return@Button
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    viewModel.register(
                                        username = regUsername,
                                        password = regPassword,
                                        fullName = regFullName,
                                        department = regDepartment,
                                        phone = regPhone,
                                        onSuccess = {
                                            isLoading = false
                                            successNotice = "ثبت‌نام انجام شد. حساب شما در وضعیت «Pending» است و باید توسط مدیر تأیید گردد."
                                            loginUsername = regUsername
                                            selectedTabIndex = 0
                                        },
                                        onError = { err ->
                                            isLoading = false
                                            errorMessage = err
                                        }
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("btn_submit_register"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
                            ) {
                                if (isLoading) {
                                    CircularProgressIndicator(
                                        color = Color.White,
                                        modifier = Modifier.size(22.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Text("ثبت نام و ارسال برای بررسی ادمین", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
