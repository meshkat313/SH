package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Meshkat Brand Colors (Deep Emerald & Gold & Persian Navy)
val MeshkatPrimary = Color(0xFF0F4C3A)
val MeshkatPrimaryDark = Color(0xFF26A67A)
val MeshkatSecondary = Color(0xFFD4AF37) // Warm Gold
val MeshkatSecondaryDark = Color(0xFFE5C158)
val MeshkatTertiary = Color(0xFF16325B) // Persian Navy
val MeshkatTertiaryDark = Color(0xFF3B6B9B)

val MeshkatBgLight = Color(0xFFF6F8F7)
val MeshkatSurfaceLight = Color(0xFFFFFFFF)
val MeshkatSurfaceVariantLight = Color(0xFFE8ECE9)

val MeshkatBgDark = Color(0xFF0B1411)
val MeshkatSurfaceDark = Color(0xFF13201C)
val MeshkatSurfaceVariantDark = Color(0xFF1C2C27)

// Status & Accents
val StatusPending = Color(0xFFD97706)
val StatusApproved = Color(0xFF15803D)
val StatusRejected = Color(0xFFB91C1C)
val StatusInvestigating = Color(0xFF2563EB)

val UsdGreen = Color(0xFF10B981)
val UsdRed = Color(0xFFEF4444)
val UsdGold = Color(0xFFF59E0B)

val CardBorderLight = Color(0x1F0F4C3A)
val CardBorderDark = Color(0x3326A67A)
