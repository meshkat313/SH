package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatChannelEntity
import com.example.data.local.ChatMessageEntity
import com.example.ui.MeshkatViewModel
import com.example.ui.Screen
import com.example.ui.theme.MeshkatPrimary
import com.example.ui.theme.MeshkatSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(viewModel: MeshkatViewModel) {
    val channels by viewModel.chatChannels.collectAsState(initial = emptyList())
    val onlineUsers by viewModel.onlineUsers.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var showNewChannelDialog by remember { mutableStateOf(false) }

    val filtered = channels.filter {
        it.title.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("پیام‌رسان امن مشکات", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF26A67A))
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "حضور بلادرنگ فعال • وب‌سوکت متصل",
                                fontSize = 10.sp,
                                color = Color(0xFFA6E3C0)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MeshkatPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewChannelDialog = true },
                containerColor = MeshkatPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("btn_new_chat_group")
            ) {
                Icon(Icons.Default.Add, contentDescription = "گروه جدید")
            }
        },
        modifier = Modifier.testTag("chat_list_screen")
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("جستجو در کانال‌ها و گروه‌ها...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
                    .testTag("chat_search_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered, key = { it.id }) { channel ->
                    ChannelListItem(
                        channel = channel,
                        isOnline = true,
                        onClick = { viewModel.openChatRoom(channel) }
                    )
                }
            }
        }
    }

    if (showNewChannelDialog) {
        NewChannelDialog(
            onDismiss = { showNewChannelDialog = false },
            onCreate = { title, desc ->
                showNewChannelDialog = false
                viewModel.showMessage("گروه امن «$title» ایجاد گردید.")
            }
        )
    }
}

@Composable
fun ChannelListItem(
    channel: ChatChannelEntity,
    isOnline: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("channel_item_${channel.id}"),
        color = MaterialTheme.colorScheme.surface
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar with Online Indicator Dot
            Box(modifier = Modifier.size(50.dp)) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(MeshkatPrimary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Group,
                        contentDescription = null,
                        tint = MeshkatPrimary,
                        modifier = Modifier.size(26.dp)
                    )
                }

                if (isOnline) {
                    Box(
                        modifier = Modifier
                            .size(13.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .align(Alignment.BottomEnd),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF26A67A))
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = channel.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = formatTime(channel.lastMessageTime),
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (channel.lastMessage.isBlank()) channel.description else channel.lastMessage,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    if (channel.unreadCount > 0) {
                        Surface(
                            shape = CircleShape,
                            color = MeshkatPrimary
                        ) {
                            Text(
                                text = channel.unreadCount.toString(),
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatRoomScreen(viewModel: MeshkatViewModel) {
    val channel by viewModel.selectedChannel.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val channelId = channel?.id ?: "ch_general"
    val messagesFlow = remember(channelId) { viewModel.repository.getChatMessages(channelId) }
    val messages by messagesFlow.collectAsState(initial = emptyList())

    val typingStatusMap by viewModel.typingStatus.collectAsState()
    val currentTyping = typingStatusMap[channelId]

    var inputText by remember { mutableStateOf("") }
    var showAttachmentDialog by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = channel?.title ?: "کانال گفتگو",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            maxLines = 1
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF26A67A))
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = if (currentTyping != null) currentTyping else "برخط (Online) • ارتباط رمزگذاری شده",
                                fontSize = 11.sp,
                                color = if (currentTyping != null) Color(0xFFFFD54F) else Color(0xFFA6E3C0),
                                fontWeight = if (currentTyping != null) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                actions = {
                    // VoIP Audio Call Button
                    IconButton(
                        onClick = { viewModel.startVoipCall(channel?.title ?: "مکالمه صوتی", isVideo = false) },
                        modifier = Modifier.testTag("btn_voip_audio_call")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "تماس صوتی", tint = Color.White)
                    }

                    // VoIP Video Call Button
                    IconButton(
                        onClick = { viewModel.startVoipCall(channel?.title ?: "مکالمه تصویری", isVideo = true) },
                        modifier = Modifier.testTag("btn_voip_video_call")
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "تماس تصویری", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MeshkatPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.testTag("chat_room_screen")
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFEFE7DE))
        ) {
            // Messages List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMine = msg.senderId == currentUser?.id || msg.isMine
                    ChatMessageBubble(msg = msg, isMine = isMine)
                }
            }

            // Real-time Typing Indicator Banner
            AnimatedVisibility(
                visible = currentTyping != null,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .testTag("typing_indicator")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "✍️ $currentTyping",
                            fontSize = 11.sp,
                            color = MeshkatPrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Input Bar with live typing emission
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 4.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showAttachmentDialog = true },
                        modifier = Modifier.testTag("btn_chat_attach")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AttachFile,
                            contentDescription = "پیوست فایل",
                            tint = MeshkatPrimary
                        )
                    }

                    OutlinedTextField(
                        value = inputText,
                        onValueChange = {
                            inputText = it
                            viewModel.onUserTyping(channelId, it)
                        },
                        placeholder = { Text("پیام خود را بنویسید...", fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input"),
                        shape = RoundedCornerShape(20.dp),
                        maxLines = 4
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    FloatingActionButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.sendChatMessage(
                                    channelId = channelId,
                                    text = inputText.trim()
                                )
                                inputText = ""
                            }
                        },
                        containerColor = MeshkatPrimary,
                        contentColor = Color.White,
                        shape = CircleShape,
                        modifier = Modifier
                            .size(44.dp)
                            .testTag("btn_send_chat")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "ارسال",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }

    if (showAttachmentDialog) {
        AttachmentPickerDialog(
            onDismiss = { showAttachmentDialog = false },
            onPick = { type, filename ->
                showAttachmentDialog = false
                viewModel.sendChatMessage(
                    channelId = channelId,
                    text = "ارسال فایل ضمیمه: $filename",
                    attachmentType = type,
                    attachmentName = filename
                )
            }
        )
    }
}

@Composable
fun ChatMessageBubble(msg: ChatMessageEntity, isMine: Boolean) {
    val bubbleColor = if (isMine) Color(0xFFD9FDD3) else Color.White
    val align = if (isMine) Alignment.CenterEnd else Alignment.CenterStart

    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = align
    ) {
        Card(
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomStart = if (isMine) 14.dp else 2.dp,
                bottomEnd = if (isMine) 2.dp else 14.dp
            ),
            colors = CardDefaults.cardColors(containerColor = bubbleColor),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.widthIn(max = 290.dp)
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                if (!isMine) {
                    Text(
                        text = "${msg.senderName} (${msg.senderRole})",
                        color = Color(0xFF0F4C3A),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                }

                if (msg.attachmentType != "NONE") {
                    AttachmentPreviewBox(
                        type = msg.attachmentType,
                        name = msg.attachmentName
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Text(
                    text = msg.messageText,
                    fontSize = 13.sp,
                    color = Color(0xFF111B21)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatTime(msg.timestamp),
                        fontSize = 10.sp,
                        color = Color(0xFF667781)
                    )
                    if (isMine) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.DoneAll,
                            contentDescription = null,
                            tint = Color(0xFF53BDEB),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AttachmentPreviewBox(type: String, name: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = Color(0xFFE9EDEF),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (type == "IMAGE") Icons.Default.Image else Icons.Default.InsertDriveFile,
                contentDescription = null,
                tint = MeshkatPrimary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = name.ifBlank { if (type == "IMAGE") "تصویر پیوست" else "سند ضمیمه" },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF111B21),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (type == "IMAGE") "فرمت تصویر JPEG" else "سند رسمی PDF",
                    fontSize = 10.sp,
                    color = Color(0xFF667781)
                )
            }
        }
    }
}

@Composable
fun AttachmentPickerDialog(
    onDismiss: () -> Unit,
    onPick: (type: String, filename: String) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("انتخاب فایل پیوست", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF0F4F2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPick("IMAGE", "تصویر_میدانی_حراست_${(10..99).random()}.jpg") }
                        .testTag("pick_image_option")
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Image, contentDescription = null, tint = MeshkatPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("ارسال تصویر و عکس مستند")
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF0F4F2),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPick("DOCUMENT", "فاکتور_و_سند_مالی_${(100..999).random()}.pdf") }
                        .testTag("pick_doc_option")
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = MeshkatPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("ارسال سند و فایل رسمی (PDF/DOC)")
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@Composable
fun NewChannelDialog(
    onDismiss: () -> Unit,
    onCreate: (title: String, desc: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ایجاد گروه یا کانال ارتباطی جدید", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("نام گروه / دپارتمان") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = desc,
                    onValueChange = { desc = it },
                    label = { Text("توضیحات و مأموریت گروه") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) onCreate(title, desc)
                },
                colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
            ) {
                Text("ایجاد گروه")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

fun formatTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
