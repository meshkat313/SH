package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = MeshkatPrimaryDark,
    onPrimary = Color(0xFF003827),
    primaryContainer = Color(0xFF0F4C3A),
    onPrimaryContainer = Color(0xFFA6F3D4),
    secondary = MeshkatSecondaryDark,
    onSecondary = Color(0xFF3B2F00),
    secondaryContainer = Color(0xFF554400),
    onSecondaryContainer = Color(0xFFFFDF88),
    tertiary = MeshkatTertiaryDark,
    background = MeshkatBgDark,
    surface = MeshkatSurfaceDark,
    surfaceVariant = MeshkatSurfaceVariantDark,
    onBackground = Color(0xFFE2E3E0),
    onSurface = Color(0xFFE2E3E0),
    onSurfaceVariant = Color(0xFFC0C9C3)
)

private val LightColorScheme = lightColorScheme(
    primary = MeshkatPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB5EED5),
    onPrimaryContainer = Color(0xFF002115),
    secondary = MeshkatSecondary,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFEDB7),
    onSecondaryContainer = Color(0xFF261D00),
    tertiary = MeshkatTertiary,
    background = MeshkatBgLight,
    surface = MeshkatSurfaceLight,
    surfaceVariant = MeshkatSurfaceVariantLight,
    onBackground = Color(0xFF191C1B),
    onSurface = Color(0xFF191C1B),
    onSurfaceVariant = Color(0xFF3F4944)
)

@Composable
fun MeshkatTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded Meshkat emerald/gold theme by default
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
