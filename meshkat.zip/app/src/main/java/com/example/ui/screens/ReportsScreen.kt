package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ReportEntity
import com.example.ui.MeshkatViewModel
import com.example.ui.Screen
import com.example.ui.theme.MeshkatPrimary
import com.example.ui.theme.MeshkatSecondary
import com.example.ui.theme.StatusApproved
import com.example.ui.theme.StatusInvestigating
import com.example.ui.theme.StatusPending
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: MeshkatViewModel) {
    val reports by viewModel.allReports.collectAsState(initial = emptyList())
    val currentUser by viewModel.currentUser.collectAsState()
    var selectedFilterIndex by remember { mutableIntStateOf(0) }
    var selectedReportForReview by remember { mutableStateOf<ReportEntity?>(null) }

    val filterCategories = listOf("همه گزارش‌ها", "در انتظار بررسی", "در حال رسیدگی", "مختومه / اقدام شده")

    val filteredReports = reports.filter { report ->
        when (selectedFilterIndex) {
            1 -> report.status == "PENDING"
            2 -> report.status == "INVESTIGATING"
            3 -> report.status == "RESOLVED"
            else -> true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("سامانه ثبت و پیگیری گزارشات", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MeshkatPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.navigateTo(Screen.NEW_REPORT) },
                containerColor = MeshkatPrimary,
                contentColor = Color.White,
                modifier = Modifier.testTag("btn_add_report")
            ) {
                Icon(Icons.Default.Add, contentDescription = "ثبت گزارش جدید")
            }
        },
        modifier = Modifier.testTag("reports_screen")
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Status Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedFilterIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MeshkatPrimary,
                edgePadding = 12.dp
            ) {
                filterCategories.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedFilterIndex == index,
                        onClick = { selectedFilterIndex = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedFilterIndex == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 12.sp
                            )
                        }
                    )
                }
            }

            if (filteredReports.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Assignment,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "هیچ گزارشی در این بخش یافت نشد",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { viewModel.navigateTo(Screen.NEW_REPORT) },
                            colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
                        ) {
                            Text("ثبت اولین گزارش رسمی")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredReports, key = { it.id }) { report ->
                        ReportCardItem(
                            report = report,
                            canReview = currentUser?.role == "ADMIN" || currentUser?.role == "MANAGER",
                            onClick = {
                                if (currentUser?.role == "ADMIN" || currentUser?.role == "MANAGER") {
                                    selectedReportForReview = report
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    selectedReportForReview?.let { report ->
        ReportReviewDialog(
            report = report,
            onDismiss = { selectedReportForReview = null },
            onUpdateStatus = { status, note ->
                viewModel.updateReportStatus(report.id, status, note)
                selectedReportForReview = null
            }
        )
    }
}

@Composable
fun ReportCardItem(
    report: ReportEntity,
    canReview: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("report_item_${report.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row: Tracking code + Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        text = "کد رهگیری: ${report.trackingCode}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }

                StatusPill(status = report.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = report.title,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = report.description,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Admin Note if available
            if (report.adminNote.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF1F8E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = Color(0xFF33691E), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "دستور حراست/مدیریت: ${report.adminNote}",
                            fontSize = 11.sp,
                            color = Color(0xFF33691E),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Footer info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PriorityPill(priority = report.priority)
                    Spacer(modifier = Modifier.width(6.dp))
                    CategoryPill(category = report.category)
                }

                Text(
                    text = "${report.userName} • ${formatDate(report.createdAt)}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun StatusPill(status: String) {
    val (bgColor, textColor, text) = when (status) {
        "PENDING" -> Triple(StatusPending.copy(alpha = 0.15f), StatusPending, "در انتظار بررسی")
        "INVESTIGATING" -> Triple(StatusInvestigating.copy(alpha = 0.15f), StatusInvestigating, "در حال رسیدگی")
        "RESOLVED" -> Triple(StatusApproved.copy(alpha = 0.15f), StatusApproved, "مختومه / اقدام شده")
        else -> Triple(Color.Gray.copy(alpha = 0.15f), Color.DarkGray, status)
    }

    Surface(shape = RoundedCornerShape(12.dp), color = bgColor) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun PriorityPill(priority: String) {
    val isUrgent = priority.contains("بحرانی") || priority.contains("فوری")
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isUrgent) Color(0xFFFFEBEE) else Color(0xFFFFF8E1)
    ) {
        Text(
            text = priority,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = if (isUrgent) Color(0xFFC62828) else Color(0xFFF57F17),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun CategoryPill(category: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MeshkatPrimary.copy(alpha = 0.1f)
    ) {
        Text(
            text = category,
            fontSize = 10.sp,
            color = MeshkatPrimary,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun ReportReviewDialog(
    report: ReportEntity,
    onDismiss: () -> Unit,
    onUpdateStatus: (newStatus: String, note: String) -> Unit
) {
    var status by remember { mutableStateOf(report.status) }
    var note by remember { mutableStateOf(report.adminNote) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("رسیدگی مدیریتی به گزارش: ${report.trackingCode}", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = "موضوع: ${report.title}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(text = "ثبت‌کننده: ${report.userName} (${report.userDepartment})", fontSize = 12.sp)

                Text(text = "تعیین وضعیت نهایی:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "PENDING" to "انتظار",
                        "INVESTIGATING" to "رسیدگی",
                        "RESOLVED" to "مختومه"
                    ).forEach { (code, label) ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (status == code) MeshkatPrimary else Color(0xFFE0E0E0),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { status = code }
                        ) {
                            Text(
                                text = label,
                                color = if (status == code) Color.White else Color.Black,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("دستور و توضیحات حراست / مدیریت") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onUpdateStatus(status, note) },
                colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
            ) {
                Text("ثبت دستور نهایی")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewReportScreen(viewModel: MeshkatViewModel) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("امنیتی") }
    var priority by remember { mutableStateOf("متوسط") }
    var description by remember { mutableStateOf("") }
    var attachmentName by remember { mutableStateOf("") }

    val categories = listOf("امنیتی", "عملیاتی", "فنی و زیرساخت", "حراست و تردد", "مالی و تنخواه")
    val priorities = listOf("فوری و بحرانی", "بالا", "متوسط", "عادی")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("فرم ثبت گزارش رسمی", fontWeight = FontWeight.Bold, fontSize = 17.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "بازگشت")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MeshkatPrimary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        modifier = Modifier.testTag("new_report_screen")
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("عنوان گزارش رسمی") },
                placeholder = { Text("مثال: گزارش حادثه فیزیکی در انبار مرکزی") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("report_title_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            // Category Selector
            Text(text = "دسته‌بندی موضوعی:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.take(3).forEach { cat ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (category == cat) MeshkatPrimary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { category = cat }
                    ) {
                        Text(
                            text = cat,
                            color = if (category == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.drop(3).forEach { cat ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (category == cat) MeshkatPrimary else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { category = cat }
                    ) {
                        Text(
                            text = cat,
                            color = if (category == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            // Priority Selector
            Text(text = "سطح اولویت و فوریت:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                priorities.forEach { p ->
                    val selected = priority == p
                    val isUrgent = p.contains("بحرانی") || p.contains("بالا")
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (selected) (if (isUrgent) Color(0xFFC62828) else MeshkatPrimary) else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { priority = p }
                    ) {
                        Text(
                            text = p,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            // Description
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("شرح کامل واقعه یا رویداد") },
                placeholder = { Text("جزئیات زمان، مکان، افراد درگیر و اقدامات صورت گرفته...") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .testTag("report_desc_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // Attachment Simulation
            OutlinedTextField(
                value = attachmentName,
                onValueChange = { attachmentName = it },
                label = { Text("پیوست مدرک / مستندات (اختیاری)") },
                placeholder = { Text("نام فایل یا عکس پیوست...") },
                trailingIcon = {
                    IconButton(onClick = { attachmentName = "مستند_پیوست_${(100..999).random()}.jpg" }) {
                        Icon(Icons.Default.AttachFile, contentDescription = "انتخاب فایل")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = {
                    if (title.isNotBlank() && description.isNotBlank()) {
                        viewModel.submitReport(
                            title = title.trim(),
                            category = category,
                            priority = priority,
                            description = description.trim(),
                            attachmentName = attachmentName.trim(),
                            onComplete = {}
                        )
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("btn_submit_report_form"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MeshkatPrimary)
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("ثبت نهایی و ارسال به کارتابل حراست", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
