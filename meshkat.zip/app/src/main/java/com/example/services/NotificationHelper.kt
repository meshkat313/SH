package com.example.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R
import java.security.SecureRandom
import java.util.UUID

class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_CHAT = "meshkat_channel_chat"
        const val CHANNEL_ANNOUNCEMENTS = "meshkat_channel_announcements"
        const val CHANNEL_REPORTS = "meshkat_channel_reports"

        private const val PREFS_NAME = "meshkat_secure_notifications"
        private const val KEY_PUSH_TOKEN = "device_push_token"

        fun getOrCreateSecurePushToken(context: Context): String {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            var token = prefs.getString(KEY_PUSH_TOKEN, null)
            if (token == null) {
                // Generate a secure 32-byte hexadecimal device push token
                val random = SecureRandom()
                val bytes = ByteArray(24)
                random.nextBytes(bytes)
                val hex = bytes.joinToString("") { "%02x".format(it) }
                token = "mshkt_push_${UUID.randomUUID().toString().take(8)}_$hex"
                prefs.edit().putString(KEY_PUSH_TOKEN, token).apply()
            }
            return token
        }
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val chatChannel = NotificationChannel(
                CHANNEL_CHAT,
                "پیام‌های چت مشکات (Chat Messages)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اعلان پیام‌های جدید در کانال‌های گفتگو و گروه‌ها"
                enableVibration(true)
            }

            val announcementChannel = NotificationChannel(
                CHANNEL_ANNOUNCEMENTS,
                "اطلاعیه‌ها و بخشنامه‌ها (Announcements)",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "اعلان انتشار بخشنامه‌های فوری و رسمی سازمان"
                enableVibration(true)
            }

            val reportChannel = NotificationChannel(
                CHANNEL_REPORTS,
                "وضعیت گزارشات امنیتی (Report Status Updates)",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "اطلاع‌رسانی تغییر وضعیت و دستورات صادره برای گزارش‌های ارسالی شما"
                enableVibration(true)
            }

            notificationManager.createNotificationChannel(chatChannel)
            notificationManager.createNotificationChannel(announcementChannel)
            notificationManager.createNotificationChannel(reportChannel)
        }
    }

    fun triggerChatNotification(channelTitle: String, senderName: String, messageText: String, notificationId: Int = (1000..9999).random()) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_CHAT)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("پیام جدید در $channelTitle")
            .setContentText("$senderName: $messageText")
            .setStyle(NotificationCompat.BigTextStyle().bigText("$senderName: $messageText"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (_: SecurityException) {
            // Permission not granted or restricted
        }
    }

    fun triggerAnnouncementNotification(title: String, content: String, author: String, notificationId: Int = (10000..19999).random()) {
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ANNOUNCEMENTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("📢 اطلاعیه رسمی: $title")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$content\n\nصادرکننده: $author"))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (_: SecurityException) {
        }
    }

    fun triggerReportStatusNotification(reportTitle: String, newStatus: String, adminNote: String, notificationId: Int = (20000..29999).random()) {
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val statusText = when (newStatus) {
            "RESOLVED" -> "مختومه / اقدام شده"
            "INVESTIGATING" -> "در حال رسیدگی"
            "PENDING" -> "در انتظار بررسی"
            else -> newStatus
        }

        val body = "وضعیت گزارش «$reportTitle» به «$statusText» تغییر یافت." +
                if (adminNote.isNotBlank()) "\nدستور مدیریت: $adminNote" else ""

        val builder = NotificationCompat.Builder(context, CHANNEL_REPORTS)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("🛡️ بروزرسانی گزارش امنیتی")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        try {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        } catch (_: SecurityException) {
        }
    }
}
