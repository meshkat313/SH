package com.example.data.local

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "users",
    indices = [Index(value = ["username"], unique = true)]
)
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val username: String,
    val password: String,
    val fullName: String,
    val department: String,
    val role: String = "USER", // "ADMIN", "MANAGER", "OPERATOR", "USER"
    val status: String = "PENDING", // "PENDING", "APPROVED", "REJECTED"
    val canAccessLedger: Boolean = false,
    val canAccessReports: Boolean = true,
    val canAccessChat: Boolean = true,
    val canAccessAnnouncements: Boolean = true,
    val canAccessAdmin: Boolean = false,
    val phoneNumber: String = "",
    val isTwoFactorEnabled: Boolean = false,
    val twoFactorSecret: String = "MSHK-2FA-SEC",
    val isOnline: Boolean = false,
    val lastSeen: Long = System.currentTimeMillis(),
    val pushToken: String = "",
    val biometricEnabled: Boolean = false,
    val biometricToken: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ticker")
data class TickerEntity(
    @PrimaryKey
    val id: Int = 1,
    val messageText: String,
    val isActive: Boolean = true,
    val speedMs: Int = 35,
    val updatedAt: Long = System.currentTimeMillis(),
    val updatedBy: String = "مدیریت سیستم"
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val tag: String = "اطلاعیه رسمی", // فوری, اداری, امنیتی, مالی
    val isPinned: Boolean = true,
    val authorName: String = "دبیرخانه مرکزی مشکات",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "reports",
    indices = [
        Index(value = ["userId"]),
        Index(value = ["status"])
    ]
)
data class ReportEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val userName: String,
    val userDepartment: String,
    val title: String,
    val category: String, // امنیتی, عملیاتی, فنی و زیرساخت, حراست, مالی
    val priority: String, // بحرانی, بالا, متوسط, عادی
    val description: String,
    val attachmentName: String = "",
    val status: String = "PENDING", // PENDING, INVESTIGATING, RESOLVED
    val adminNote: String = "",
    val trackingCode: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "financial_ledger",
    indices = [
        Index(value = ["sectionType"]),
        Index(value = ["dateStr"])
    ]
)
data class LedgerEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sectionType: String, // "BUDGET_RECEIVED" or "CORE_EXPENSE"
    val title: String,
    val amountTomans: Long,
    val categoryOrSource: String, // e.g. "تخصیص ستادی", "حقوق و دستمزد", "تجهیزات فنی"
    val dateStr: String,
    val referenceCode: String,
    val paymentMethod: String = "حواله بانکی پایا",
    val fiscalYear: String = "۱۴۰۳",
    val auditStatus: String = "AUDITED", // "AUDITED", "UNDER_REVIEW"
    val currencyUnit: String = "TOMAN",
    val description: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_channels")
data class ChatChannelEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val description: String,
    val channelType: String = "GROUP", // GROUP, DIRECT
    val unreadCount: Int = 0,
    val lastMessage: String = "",
    val lastMessageTime: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "chat_messages",
    indices = [Index(value = ["channelId"])]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val channelId: String,
    val senderId: Long,
    val senderName: String,
    val senderRole: String,
    val messageText: String,
    val attachmentType: String = "NONE", // NONE, IMAGE, DOCUMENT, AUDIO
    val attachmentName: String = "",
    val isVoiceStub: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val isMine: Boolean = false
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long = 0, // 0 for broadcast to all users
    val title: String,
    val message: String,
    val type: String, // "CHAT", "ANNOUNCEMENT", "REPORT_STATUS", "SYSTEM"
    val referenceId: String = "",
    val isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
