package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE status = 'PENDING' ORDER BY createdAt DESC")
    fun getPendingUsers(): Flow<List<UserEntity>>

    @Query("SELECT COUNT(*) FROM users WHERE status = 'PENDING'")
    fun getPendingUsersCount(): Flow<Int>

    @Query("SELECT * FROM users WHERE isOnline = 1")
    fun getOnlineUsers(): Flow<List<UserEntity>>

    @Query("SELECT * FROM users WHERE id = :id LIMIT 1")
    suspend fun getUserById(id: Long): UserEntity?

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String)

    @Query("UPDATE users SET isOnline = :isOnline, lastSeen = :lastSeen WHERE id = :id")
    suspend fun updatePresence(id: Long, isOnline: Boolean, lastSeen: Long)

    @Query("UPDATE users SET isTwoFactorEnabled = :enabled, twoFactorSecret = :secret WHERE id = :id")
    suspend fun update2fa(id: Long, enabled: Boolean, secret: String)

    @Query("UPDATE users SET pushToken = :token WHERE id = :id")
    suspend fun updatePushToken(id: Long, token: String)

    @Query("""
        UPDATE users 
        SET role = :role, 
            canAccessLedger = :canAccessLedger, 
            canAccessReports = :canAccessReports, 
            canAccessChat = :canAccessChat, 
            canAccessAnnouncements = :canAccessAnnouncements, 
            canAccessAdmin = :canAccessAdmin 
        WHERE id = :id
    """)
    suspend fun updatePermissions(
        id: Long,
        role: String,
        canAccessLedger: Boolean,
        canAccessReports: Boolean,
        canAccessChat: Boolean,
        canAccessAnnouncements: Boolean,
        canAccessAdmin: Boolean
    )

    @Query("DELETE FROM users WHERE id = :id")
    suspend fun deleteUser(id: Long)
}

@Dao
interface TickerDao {
    @Query("SELECT * FROM ticker WHERE id = 1 LIMIT 1")
    fun getTicker(): Flow<TickerEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveTicker(ticker: TickerEntity)
}

@Dao
interface AnnouncementDao {
    @Query("SELECT * FROM announcements ORDER BY createdAt DESC")
    fun getAllAnnouncements(): Flow<List<AnnouncementEntity>>

    @Query("SELECT * FROM announcements WHERE isPinned = 1 ORDER BY createdAt DESC")
    fun getPinnedAnnouncements(): Flow<List<AnnouncementEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnnouncement(announcement: AnnouncementEntity): Long

    @Query("DELETE FROM announcements WHERE id = :id")
    suspend fun deleteAnnouncement(id: Long)
}

@Dao
interface ReportDao {
    @Query("SELECT * FROM reports ORDER BY createdAt DESC")
    fun getAllReports(): Flow<List<ReportEntity>>

    @Query("SELECT * FROM reports WHERE userId = :userId ORDER BY createdAt DESC")
    fun getReportsByUser(userId: Long): Flow<List<ReportEntity>>

    @Query("SELECT * FROM reports WHERE id = :id LIMIT 1")
    suspend fun getReportById(id: Long): ReportEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity): Long

    @Query("UPDATE reports SET status = :status, adminNote = :note WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, note: String)

    @Query("DELETE FROM reports WHERE id = :id")
    suspend fun deleteReport(id: Long)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM financial_ledger ORDER BY createdAt DESC")
    fun getAllEntries(): Flow<List<LedgerEntryEntity>>

    @Query("SELECT * FROM financial_ledger WHERE sectionType = :sectionType ORDER BY createdAt DESC")
    fun getEntriesBySection(sectionType: String): Flow<List<LedgerEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEntry(entry: LedgerEntryEntity): Long

    @Query("DELETE FROM financial_ledger WHERE id = :id")
    suspend fun deleteEntry(id: Long)

    @Query("SELECT SUM(amountTomans) FROM financial_ledger WHERE sectionType = 'BUDGET_RECEIVED'")
    fun getTotalBudget(): Flow<Long?>

    @Query("SELECT SUM(amountTomans) FROM financial_ledger WHERE sectionType = 'CORE_EXPENSE'")
    fun getTotalExpenses(): Flow<Long?>
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_channels ORDER BY lastMessageTime DESC")
    fun getAllChannels(): Flow<List<ChatChannelEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: ChatChannelEntity)

    @Query("SELECT * FROM chat_messages WHERE channelId = :channelId ORDER BY timestamp ASC")
    fun getMessagesForChannel(channelId: String): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("UPDATE chat_channels SET lastMessage = :lastMsg, lastMessageTime = :time WHERE id = :channelId")
    suspend fun updateLastMessage(channelId: String, lastMsg: String, time: Long)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId OR userId = 0 ORDER BY createdAt DESC")
    fun getNotificationsForUser(userId: Long): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE (userId = :userId OR userId = 0) AND isRead = 0")
    fun getUnreadCount(userId: Long): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: Long)

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId OR userId = 0")
    suspend fun markAllAsRead(userId: Long)
}
