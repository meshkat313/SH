package com.example.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Robust Room Database Migration Strategy for Meshkat Application.
 * Preserves all existing production user profiles, financial ledger entries,
 * reports, announcements, and chat channels without any data loss.
 */
object DatabaseMigrations {

    /**
     * Migration from Version 1 to Version 2:
     * - Adds Two-Factor Authentication (2FA), real-time presence, and push token columns to `users` table.
     * - Creates `notifications` table for unified push notification management.
     */
    val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            // Safely alter users table
            db.execSQL("ALTER TABLE users ADD COLUMN isTwoFactorEnabled INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE users ADD COLUMN twoFactorSecret TEXT NOT NULL DEFAULT 'MSHK-2FA-SEC'")
            db.execSQL("ALTER TABLE users ADD COLUMN isOnline INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE users ADD COLUMN lastSeen INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE users ADD COLUMN pushToken TEXT NOT NULL DEFAULT ''")

            // Create notifications table if not exists
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS notifications (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    userId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    message TEXT NOT NULL,
                    type TEXT NOT NULL,
                    referenceId TEXT NOT NULL,
                    isRead INTEGER NOT NULL,
                    createdAt INTEGER NOT NULL
                )
            """.trimIndent())
        }
    }

    /**
     * Migration from Version 2 to Version 3:
     * - Adds Biometric authentication credentials to `users` table.
     * - Adds fiscal governance fields (`fiscalYear`, `auditStatus`, `currencyUnit`) to `financial_ledger` table.
     * - Adds index optimizations for fast querying of financial ledger and reports.
     */
    val MIGRATION_2_3 = object : Migration(2, 3) {
        override fun migrate(db: SupportSQLiteDatabase) {
            // Add Biometric flags to users
            db.execSQL("ALTER TABLE users ADD COLUMN biometricEnabled INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE users ADD COLUMN biometricToken TEXT NOT NULL DEFAULT ''")

            // Add Governance & Audit columns to financial_ledger
            db.execSQL("ALTER TABLE financial_ledger ADD COLUMN fiscalYear TEXT NOT NULL DEFAULT '۱۴۰۳'")
            db.execSQL("ALTER TABLE financial_ledger ADD COLUMN auditStatus TEXT NOT NULL DEFAULT 'AUDITED'")
            db.execSQL("ALTER TABLE financial_ledger ADD COLUMN currencyUnit TEXT NOT NULL DEFAULT 'TOMAN'")

            // Add Performance Query Indexes
            db.execSQL("CREATE INDEX IF NOT EXISTS index_financial_ledger_sectionType ON financial_ledger (sectionType)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_financial_ledger_dateStr ON financial_ledger (dateStr)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_reports_userId ON reports (userId)")
            db.execSQL("CREATE INDEX IF NOT EXISTS index_reports_status ON reports (status)")
        }
    }

    val ALL_MIGRATIONS = arrayOf(MIGRATION_1_2, MIGRATION_2_3)
}
