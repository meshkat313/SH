package com.example.data.repository

import android.content.Context
import com.example.data.local.AnnouncementDao
import com.example.data.local.AnnouncementEntity
import com.example.data.local.AppDatabase
import com.example.data.local.ChatChannelEntity
import com.example.data.local.ChatDao
import com.example.data.local.ChatMessageEntity
import com.example.data.local.LedgerDao
import com.example.data.local.LedgerEntryEntity
import com.example.data.local.NotificationDao
import com.example.data.local.NotificationEntity
import com.example.data.local.ReportDao
import com.example.data.local.ReportEntity
import com.example.data.local.TickerDao
import com.example.data.local.TickerEntity
import com.example.data.local.UserDao
import com.example.data.local.UserEntity
import com.example.data.remote.CurrencyScraperService
import com.example.data.remote.UsdRateData
import com.example.services.ChatWebSocketManager
import com.example.services.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class AuthResult {
    data class Success(val user: UserEntity) : AuthResult()
    data class PendingApproval(val user: UserEntity) : AuthResult()
    data class RequiresTwoFactor(val user: UserEntity, val tempOtpCode: String) : AuthResult()
    data class Rejected(val reason: String) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

data class FinancialSummary(
    val totalBudget: Long = 0L,
    val totalExpenses: Long = 0L,
    val netBalance: Long = 0L,
    val expenseRatio: Float = 0f
)

class MeshkatRepository(
    private val database: AppDatabase,
    private val context: Context? = null,
    private val scraperService: CurrencyScraperService = CurrencyScraperService(),
    val webSocketManager: ChatWebSocketManager = ChatWebSocketManager(),
    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
) {
    private val userDao: UserDao = database.userDao()
    private val tickerDao: TickerDao = database.tickerDao()
    private val announcementDao: AnnouncementDao = database.announcementDao()
    private val reportDao: ReportDao = database.reportDao()
    private val ledgerDao: LedgerDao = database.ledgerDao()
    private val chatDao: ChatDao = database.chatDao()
    private val notificationDao: NotificationDao = database.notificationDao()

    private val notificationHelper: NotificationHelper? = context?.let { NotificationHelper(it) }

    private val _currentUser = MutableStateFlow<UserEntity?>(null)
    val currentUser: StateFlow<UserEntity?> = _currentUser.asStateFlow()

    private val _pending2faUser = MutableStateFlow<Pair<UserEntity, String>?>(null)
    val pending2faUser: StateFlow<Pair<UserEntity, String>?> = _pending2faUser.asStateFlow()

    private val _usdRate = MutableStateFlow(UsdRateData())
    val usdRate: StateFlow<UsdRateData> = _usdRate.asStateFlow()

    private val _isScrapingUsd = MutableStateFlow(false)
    val isScrapingUsd: StateFlow<Boolean> = _isScrapingUsd.asStateFlow()

    // Flows
    val allUsers: Flow<List<UserEntity>> = userDao.getAllUsers()
    val pendingUsers: Flow<List<UserEntity>> = userDao.getPendingUsers()
    val pendingUsersCount: Flow<Int> = userDao.getPendingUsersCount()

    val ticker: Flow<TickerEntity?> = tickerDao.getTicker()
    val announcements: Flow<List<AnnouncementEntity>> = announcementDao.getAllAnnouncements()
    val pinnedAnnouncements: Flow<List<AnnouncementEntity>> = announcementDao.getPinnedAnnouncements()

    val allReports: Flow<List<ReportEntity>> = reportDao.getAllReports()
    fun getReportsForUser(userId: Long): Flow<List<ReportEntity>> = reportDao.getReportsByUser(userId)

    val allLedgerEntries: Flow<List<LedgerEntryEntity>> = ledgerDao.getAllEntries()
    val budgetEntries: Flow<List<LedgerEntryEntity>> = ledgerDao.getEntriesBySection("BUDGET_RECEIVED")
    val expenseEntries: Flow<List<LedgerEntryEntity>> = ledgerDao.getEntriesBySection("CORE_EXPENSE")

    val financialSummary: Flow<FinancialSummary> = combine(
        ledgerDao.getTotalBudget(),
        ledgerDao.getTotalExpenses()
    ) { budget, expenses ->
        val b = budget ?: 0L
        val e = expenses ?: 0L
        val net = b - e
        val ratio = if (b > 0) (e.toFloat() / b.toFloat()).coerceIn(0f, 1f) else 0f
        FinancialSummary(
            totalBudget = b,
            totalExpenses = e,
            netBalance = net,
            expenseRatio = ratio
        )
    }

    val chatChannels: Flow<List<ChatChannelEntity>> = chatDao.getAllChannels()
    fun getChatMessages(channelId: String): Flow<List<ChatMessageEntity>> = chatDao.getMessagesForChannel(channelId)

    // Notifications
    val notifications: Flow<List<NotificationEntity>> = notificationDao.getNotificationsForUser(0L)
    val unreadNotificationsCount: Flow<Int> = notificationDao.getUnreadCount(0L)

    init {
        scope.launch {
            seedInitialDataIfEmpty()
            refreshUsdRate()
        }
    }

    suspend fun refreshUsdRate() {
        _isScrapingUsd.value = true
        try {
            val rate = scraperService.fetchLiveTehranUsd()
            _usdRate.value = rate
        } finally {
            _isScrapingUsd.value = false
        }
    }

    // --- Authentication & 2FA & User Management ---
    suspend fun login(username: String, pass: String): AuthResult {
        val user = userDao.getUserByUsername(username.trim())
            ?: return AuthResult.Error("نام کاربری یا رمز عبور اشتباه است.")

        if (user.password != pass) {
            return AuthResult.Error("نام کاربری یا رمز عبور اشتباه است.")
        }

        when (user.status) {
            "PENDING" -> return AuthResult.PendingApproval(user)
            "REJECTED" -> return AuthResult.Rejected("درخواست دسترسی شما توسط مدیر رد شده است. لطفاً با پشتیبانی تماس بگیرید.")
            "APPROVED" -> {
                // Check if user is an Administrator requiring 2FA
                if (user.role == "ADMIN" || user.isTwoFactorEnabled) {
                    val otpCode = "123456" // Standard demo 6-digit OTP for testing
                    _pending2faUser.value = Pair(user, otpCode)
                    return AuthResult.RequiresTwoFactor(user, otpCode)
                }

                // Normal Approved User
                completeLogin(user)
                return AuthResult.Success(user)
            }
            else -> return AuthResult.Error("وضعیت حساب نامشخص است.")
        }
    }

    suspend fun verify2fa(enteredOtp: String): Boolean {
        val pending = _pending2faUser.value ?: return false
        val (user, expectedOtp) = pending
        if (enteredOtp.trim() == expectedOtp || enteredOtp.trim() == "123456") {
            _pending2faUser.value = null
            completeLogin(user)
            return true
        }
        return false
    }

    fun cancel2fa() {
        _pending2faUser.value = null
    }

    private suspend fun completeLogin(user: UserEntity) {
        val token = context?.let { NotificationHelper.getOrCreateSecurePushToken(it) } ?: "mshkt_push_token_${user.id}"
        userDao.updatePushToken(user.id, token)
        userDao.updatePresence(user.id, true, System.currentTimeMillis())

        val updated = user.copy(pushToken = token, isOnline = true)
        _currentUser.value = updated

        // Connect WebSocket for user
        webSocketManager.connect("ch_hq", user.id, user.fullName)
    }

    suspend fun register(
        username: String,
        password: String,
        fullName: String,
        department: String,
        phone: String
    ): Result<UserEntity> {
        val existing = userDao.getUserByUsername(username.trim())
        if (existing != null) {
            return Result.failure(Exception("این نام کاربری قبلاً ثبت شده است."))
        }

        // STRICT RULE: Newly registered users ALWAYS get 'PENDING' status and are locked until Admin approves
        val pushToken = context?.let { NotificationHelper.getOrCreateSecurePushToken(it) } ?: ""
        val newUser = UserEntity(
            username = username.trim(),
            password = password,
            fullName = fullName.trim(),
            department = department.trim(),
            phoneNumber = phone.trim(),
            role = "USER",
            status = "PENDING",
            canAccessLedger = false,
            canAccessReports = true,
            canAccessChat = true,
            canAccessAnnouncements = true,
            canAccessAdmin = false,
            pushToken = pushToken
        )
        val id = userDao.insertUser(newUser)
        return Result.success(newUser.copy(id = id))
    }

    fun logout() {
        val user = _currentUser.value
        if (user != null) {
            scope.launch {
                userDao.updatePresence(user.id, false, System.currentTimeMillis())
            }
        }
        webSocketManager.disconnect()
        _currentUser.value = null
    }

    suspend fun approveUser(userId: Long) {
        userDao.updateStatus(userId, "APPROVED")
    }

    suspend fun rejectUser(userId: Long) {
        userDao.updateStatus(userId, "REJECTED")
    }

    suspend fun updateUserPermissions(
        userId: Long,
        role: String,
        canAccessLedger: Boolean,
        canAccessReports: Boolean,
        canAccessChat: Boolean,
        canAccessAnnouncements: Boolean,
        canAccessAdmin: Boolean
    ) {
        userDao.updatePermissions(
            id = userId,
            role = role,
            canAccessLedger = canAccessLedger,
            canAccessReports = canAccessReports,
            canAccessChat = canAccessChat,
            canAccessAnnouncements = canAccessAnnouncements,
            canAccessAdmin = canAccessAdmin
        )
    }

    // --- Dynamic Ticker Manager ---
    suspend fun updateTicker(newText: String, isActive: Boolean, speedMs: Int = 35) {
        val adminName = _currentUser.value?.fullName ?: "مدیریت سیستم"
        tickerDao.saveTicker(
            TickerEntity(
                id = 1,
                messageText = newText,
                isActive = isActive,
                speedMs = speedMs,
                updatedAt = System.currentTimeMillis(),
                updatedBy = adminName
            )
        )
    }

    // --- Reports Module with Status Push Notification ---
    suspend fun submitReport(
        title: String,
        category: String,
        priority: String,
        description: String,
        attachmentName: String = ""
    ): Long {
        val user = _currentUser.value ?: throw IllegalStateException("کاربر وارد نشده است.")
        val trackingCode = "MSH-" + (1000..9999).random().toString()
        val report = ReportEntity(
            userId = user.id,
            userName = user.fullName,
            userDepartment = user.department,
            title = title,
            category = category,
            priority = priority,
            description = description,
            attachmentName = attachmentName,
            status = "PENDING",
            trackingCode = trackingCode
        )
        return reportDao.insertReport(report)
    }

    suspend fun updateReportStatus(reportId: Long, newStatus: String, adminNote: String) {
        reportDao.updateStatus(reportId, newStatus, adminNote)

        // Trigger Push Notification and In-App notification
        val report = reportDao.getReportById(reportId)
        val reportTitle = report?.title ?: "گزارش امنیتی"
        notificationHelper?.triggerReportStatusNotification(reportTitle, newStatus, adminNote)

        notificationDao.insertNotification(
            NotificationEntity(
                userId = report?.userId ?: 0L,
                title = "تغییر وضعیت گزارش $reportTitle",
                message = "وضعیت: $newStatus - دستور: $adminNote",
                type = "REPORT_STATUS",
                referenceId = reportId.toString()
            )
        )
    }

    // --- Financial Ledger ---
    suspend fun addBudgetEntry(
        title: String,
        amountTomans: Long,
        source: String,
        dateStr: String,
        refCode: String,
        notes: String = ""
    ): Long {
        return ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "BUDGET_RECEIVED",
                title = title,
                amountTomans = amountTomans,
                categoryOrSource = source,
                dateStr = dateStr,
                referenceCode = refCode,
                paymentMethod = "حواله مستقیم خزانه",
                description = notes
            )
        )
    }

    suspend fun addExpenseEntry(
        title: String,
        amountTomans: Long,
        category: String,
        dateStr: String,
        refCode: String,
        paymentMethod: String,
        notes: String = ""
    ): Long {
        return ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "CORE_EXPENSE",
                title = title,
                amountTomans = amountTomans,
                categoryOrSource = category,
                dateStr = dateStr,
                referenceCode = refCode,
                paymentMethod = paymentMethod,
                description = notes
            )
        )
    }

    suspend fun deleteLedgerEntry(id: Long) {
        ledgerDao.deleteEntry(id)
    }

    // --- Announcements with Push Notification ---
    suspend fun postAnnouncement(
        title: String,
        content: String,
        tag: String,
        isPinned: Boolean
    ): Long {
        val author = _currentUser.value?.fullName ?: "دبیرخانه مشکات"
        val id = announcementDao.insertAnnouncement(
            AnnouncementEntity(
                title = title,
                content = content,
                tag = tag,
                isPinned = isPinned,
                authorName = author
            )
        )

        // Trigger system push notification for all users
        notificationHelper?.triggerAnnouncementNotification(title, content, author)

        notificationDao.insertNotification(
            NotificationEntity(
                userId = 0L, // broadcast
                title = "📢 اطلاعیه رسمی: $title",
                message = content,
                type = "ANNOUNCEMENT",
                referenceId = id.toString()
            )
        )

        return id
    }

    // --- Chat & Messaging with Push Notification ---
    suspend fun sendChatMessage(
        channelId: String,
        text: String,
        attachmentType: String = "NONE",
        attachmentName: String = "",
        isVoiceStub: Boolean = false
    ): Long {
        val user = _currentUser.value ?: throw IllegalStateException("کاربر وارد نشده است.")
        val now = System.currentTimeMillis()
        val msg = ChatMessageEntity(
            channelId = channelId,
            senderId = user.id,
            senderName = user.fullName,
            senderRole = user.role,
            messageText = text,
            attachmentType = attachmentType,
            attachmentName = attachmentName,
            isVoiceStub = isVoiceStub,
            timestamp = now,
            isMine = true
        )
        val id = chatDao.insertMessage(msg)
        val preview = if (attachmentType != "NONE") "[$attachmentType] $text" else text
        chatDao.updateLastMessage(channelId, preview, now)

        // Trigger push notification for recipient/channel
        notificationHelper?.triggerChatNotification("کانال مشکات", user.fullName, text)

        return id
    }

    suspend fun markNotificationAsRead(id: Long) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() {
        val user = _currentUser.value
        notificationDao.markAllAsRead(user?.id ?: 0L)
    }

    // --- Seed Data ---
    private suspend fun seedInitialDataIfEmpty() {
        val admin = userDao.getUserByUsername("admin")
        if (admin == null) {
            userDao.insertUser(
                UserEntity(
                    username = "admin",
                    password = "admin123",
                    fullName = "مهندس مهدوی (مدیر ارشد)",
                    department = "مدیریت عالی و حراست کل",
                    role = "ADMIN",
                    status = "APPROVED",
                    canAccessLedger = true,
                    canAccessReports = true,
                    canAccessChat = true,
                    canAccessAnnouncements = true,
                    canAccessAdmin = true,
                    phoneNumber = "۰۹۱۲۳۴۵۶۷۸۹",
                    isTwoFactorEnabled = true, // Admin 2FA enforced
                    isOnline = true
                )
            )

            // Seed a pending user to test the approval gate immediately
            userDao.insertUser(
                UserEntity(
                    username = "reza_ahmadi",
                    password = "user123",
                    fullName = "رضا احمدی",
                    department = "پشتیبانی و تدارکات میدانی",
                    role = "USER",
                    status = "PENDING",
                    canAccessLedger = false,
                    canAccessReports = true,
                    canAccessChat = true,
                    canAccessAnnouncements = true,
                    canAccessAdmin = false,
                    phoneNumber = "۰۹۱۹۸۷۶۵۴۳۲",
                    isTwoFactorEnabled = false,
                    isOnline = false
                )
            )

            // Seed an approved supervisor
            userDao.insertUser(
                UserEntity(
                    username = "sarah_rad",
                    password = "user123",
                    fullName = "سارا رادپور",
                    department = "امور مالی و حسابداری",
                    role = "MANAGER",
                    status = "APPROVED",
                    canAccessLedger = true,
                    canAccessReports = true,
                    canAccessChat = true,
                    canAccessAnnouncements = true,
                    canAccessAdmin = false,
                    phoneNumber = "۰۹۳۵۱۲۳۴۵۶۷",
                    isTwoFactorEnabled = false,
                    isOnline = true
                )
            )
        }

        // Seed initial Ticker Banner
        tickerDao.saveTicker(
            TickerEntity(
                id = 1,
                messageText = "★ سامانه جامع مشکات: پایش مداوم نرخ آزاد ارز تهران • آخرین بروزرسانی بودجه عملیاتی سه ماهه سوم • ثبت گزارشات امنیتی در دست اقدام • برقراری خطوط ارتباطی ایمن",
                isActive = true,
                speedMs = 35
            )
        )

        // Seed initial Announcements
        val now = System.currentTimeMillis()
        announcementDao.insertAnnouncement(
            AnnouncementEntity(
                title = "دستورالعمل اجرایی انضباط مالی و ثبت اسناد بودجه",
                content = "کلیه معاونت‌ها و واحدهای عملیاتی موظفند تا پایان وقت اداری روز چهارشنبه، تمامی فاکتورهای هزینه‌کرد و تنخواه‌گردان را در بخش امور مالی سامانه مشکات ثبت نمایند.",
                tag = "مالی و بودجه",
                isPinned = true,
                authorName = "معاونت اداری و مالی",
                createdAt = now - 3600000 * 5
            )
        )
        announcementDao.insertAnnouncement(
            AnnouncementEntity(
                title = "برقراری کانال‌های امن گفتگو و شیفت‌های برخط شبانه",
                content = "به اطلاع کلیه همکاران می‌رساند قابلیت مکالمات صوتی و تصویری رمزگذاری شده و تبادل فایل‌های رسمی در ماژول چت مشکات فعال گردید.",
                tag = "امنیتی و ارتباطات",
                isPinned = true,
                authorName = "حراست و فناوری اطلاعات",
                createdAt = now - 3600000 * 18
            )
        )

        // Seed Financial Ledger Data
        ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "BUDGET_RECEIVED",
                title = "تخصیص مرحله اول بودجه فصل پاییز",
                amountTomans = 850_000_000L,
                categoryOrSource = "سازمان مرکزی و خزانه",
                dateStr = "۱۴۰۳/۰۷/۱۰",
                referenceCode = "TRX-98210",
                paymentMethod = "پایا مرکزی",
                description = "بودجه مصوب هیئت مدیره برای ارتقای تجهیزات و سرورها"
            )
        )
        ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "BUDGET_RECEIVED",
                title = "تنخواه ویژه پشتیبانی پروژه‌های اضطراری",
                amountTomans = 320_000_000L,
                categoryOrSource = "ردیف اعتبارات پشتیبانی",
                dateStr = "۱۴۰۳/۰۷/۱۸",
                referenceCode = "TRX-98442",
                paymentMethod = "ساتنا",
                description = "اعتبار فوری جهت عملیات لجستیک میدانی"
            )
        )

        ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "CORE_EXPENSE",
                title = "حقوق و مزایای کادر فنی و کارشناسان",
                amountTomans = 410_000_000L,
                categoryOrSource = "حقوق و دستمزد",
                dateStr = "۱۴۰۳/۰۷/۱۵",
                referenceCode = "EXP-31002",
                paymentMethod = "واریز متمرکز بانک ملی",
                description = "تسویه حقوق ماهانه پرسنل و کارشناسان فناوری"
            )
        )
        ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "CORE_EXPENSE",
                title = "تمدید زیرساخت سرورها و ذخیره‌ساز ابری",
                amountTomans = 95_000_000L,
                categoryOrSource = "فناوری و زیرساخت",
                dateStr = "۱۴۰۳/۰۷/۱۷",
                referenceCode = "EXP-31045",
                paymentMethod = "کارت شرکتی",
                description = "ارتقای پهنای باند و امنیت فایروال مرکز داده"
            )
        )
        ledgerDao.insertEntry(
            LedgerEntryEntity(
                sectionType = "CORE_EXPENSE",
                title = "خرید تجهیزات شبکه و ذخیره‌سازی میدانی",
                amountTomans = 78_500_000L,
                categoryOrSource = "تجهیزات و ملزومات",
                dateStr = "۱۴۰۳/۰۷/۲۰",
                referenceCode = "EXP-31089",
                paymentMethod = "چک صیادی شماره ۹۰۴",
                description = "خرید سوییچ و روترهای سخت‌افزاری"
            )
        )

        // Seed Chat Channels
        chatDao.insertChannel(
            ChatChannelEntity(
                id = "ch_hq",
                title = "ستاد فرماندهی و مدیریت ارشد",
                description = "ارتباطات محرمانه و هماهنگی کلان سازمانی",
                channelType = "GROUP",
                unreadCount = 2,
                lastMessage = "جلسه اضطراری بررسی بودجه ساعت ۱۰ برگزار می‌شود.",
                lastMessageTime = now - 600000
            )
        )
        chatDao.insertChannel(
            ChatChannelEntity(
                id = "ch_security",
                title = "مرکز عملیات امنیت و حراست (SOC)",
                description = "پایش تهدیدات، رویدادها و گزارش‌های امنیتی",
                channelType = "GROUP",
                unreadCount = 0,
                lastMessage = "گزارش وضعیت دوربین‌ها و سیستم تردد دریافت شد.",
                lastMessageTime = now - 3600000
            )
        )
        chatDao.insertChannel(
            ChatChannelEntity(
                id = "ch_finance",
                title = "امور مالی و بودجه تخصیصی",
                description = "تطبیق ترازهای مالی و نوسانات نرخ ارز",
                channelType = "GROUP",
                unreadCount = 1,
                lastMessage = "نرخ لحظه‌ای دلار تهران استعلام گردید و در سامانه درج شد.",
                lastMessageTime = now - 7200000
            )
        )

        chatDao.insertMessage(
            ChatMessageEntity(
                channelId = "ch_hq",
                senderId = 1,
                senderName = "مهندس مهدوی (مدیر ارشد)",
                senderRole = "ADMIN",
                messageText = "با سلام و درود به همه همکاران گرامی. کلیه دسترسی‌ها طبق ماتریس احراز هویت تنظیم شده است.",
                timestamp = now - 1800000,
                isMine = false
            )
        )
        chatDao.insertMessage(
            ChatMessageEntity(
                channelId = "ch_hq",
                senderId = 1,
                senderName = "مهندس مهدوی (مدیر ارشد)",
                senderRole = "ADMIN",
                messageText = "جلسه اضطراری بررسی بودجه ساعت ۱۰ برگزار می‌شود.",
                timestamp = now - 600000,
                isMine = false
            )
        )

        // Seed Sample Report
        reportDao.insertReport(
            ReportEntity(
                userId = 1,
                userName = "مهندس مهدوی",
                userDepartment = "مدیریت عالی و حراست کل",
                title = "بررسی نوسان اتصال سرورهای پشتیبان به شبکه داخلی",
                category = "فنی و زیرساخت",
                priority = "بالا",
                description = "در بازه زمانی ساعت ۲۳ تا ۰۱ بامداد، ارتباط خطوط ثانویه دیتاسنتر دچار اختلال ۵ درصدی بود که با سوییچ روی بک‌آپ برطرف شد.",
                status = "RESOLVED",
                adminNote = "اقدام فوری صورت گرفت و تجهیزات روتر تعویض گردید.",
                trackingCode = "MSH-5412",
                createdAt = now - 86400000
            )
        )
    }
}
