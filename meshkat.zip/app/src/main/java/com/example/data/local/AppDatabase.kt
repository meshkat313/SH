package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserEntity::class,
        TickerEntity::class,
        AnnouncementEntity::class,
        ReportEntity::class,
        LedgerEntryEntity::class,
        ChatChannelEntity::class,
        ChatMessageEntity::class,
        NotificationEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun tickerDao(): TickerDao
    abstract fun announcementDao(): AnnouncementDao
    abstract fun reportDao(): ReportDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun chatDao(): ChatDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "meshkat_database.db"
                )
                // Production-grade migration strategy preserving existing User & Ledger records
                .addMigrations(*DatabaseMigrations.ALL_MIGRATIONS)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
