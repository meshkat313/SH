package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import com.example.ui.MeshkatViewModel
import com.example.ui.Screen
import com.example.ui.components.VoipCallDialog
import com.example.ui.screens.AdminPanelScreen
import com.example.ui.screens.AnnouncementsScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.ChatListScreen
import com.example.ui.screens.ChatRoomScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LedgerScreen
import com.example.ui.screens.NewReportScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.theme.MeshkatPrimary
import com.example.ui.theme.MeshkatTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MeshkatViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MeshkatTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    MeshkatApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun MeshkatApp(viewModel: MeshkatViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentUser by viewModel.currentUser.collectAsState()
    val activeCall by viewModel.activeVoipCall.collectAsState()
    val uiMessage by viewModel.uiMessage.collectAsState()
    val pendingUsersCount by viewModel.pendingUsersCount.collectAsState(initial = 0)

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(uiMessage) {
        uiMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearUiMessage()
        }
    }

    // Android System Back Press Handler
    BackHandler(enabled = currentScreen != Screen.DASHBOARD && currentScreen != Screen.AUTH_LOGIN) {
        viewModel.navigateBack()
    }

    val showBottomBar = currentUser != null && currentScreen in listOf(
        Screen.DASHBOARD,
        Screen.CHAT_LIST,
        Screen.REPORTS,
        Screen.LEDGER,
        Screen.ADMIN_PANEL,
        Screen.ANNOUNCEMENTS
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                MeshkatBottomNavigation(
                    currentScreen = currentScreen,
                    isAdmin = currentUser?.role == "ADMIN",
                    pendingCount = pendingUsersCount,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.AUTH_LOGIN, Screen.AUTH_REGISTER -> {
                    AuthScreen(viewModel = viewModel)
                }
                Screen.DASHBOARD -> {
                    DashboardScreen(viewModel = viewModel)
                }
                Screen.CHAT_LIST -> {
                    ChatListScreen(viewModel = viewModel)
                }
                Screen.CHAT_ROOM -> {
                    ChatRoomScreen(viewModel = viewModel)
                }
                Screen.REPORTS -> {
                    ReportsScreen(viewModel = viewModel)
                }
                Screen.NEW_REPORT -> {
                    NewReportScreen(viewModel = viewModel)
                }
                Screen.LEDGER -> {
                    LedgerScreen(viewModel = viewModel)
                }
                Screen.ANNOUNCEMENTS, Screen.NEW_ANNOUNCEMENT -> {
                    AnnouncementsScreen(viewModel = viewModel)
                }
                Screen.ADMIN_PANEL, Screen.ADMIN_USER_APPROVAL, Screen.ADMIN_PERMISSIONS, Screen.ADMIN_TICKER -> {
                    AdminPanelScreen(viewModel = viewModel)
                }
                Screen.NOTIFICATIONS -> {
                    com.example.ui.screens.NotificationsScreen(viewModel = viewModel)
                }
            }

            // VoIP Call Active Overlay/Dialog
            if (activeCall != null) {
                VoipCallDialog(
                    call = activeCall,
                    onEndCall = { viewModel.endVoipCall() },
                    onToggleMute = { viewModel.toggleVoipMute() },
                    onToggleSpeaker = { viewModel.toggleVoipSpeaker() },
                    onToggleVideo = { viewModel.toggleVoipVideo() }
                )
            }
        }
    }
}

@Composable
fun MeshkatBottomNavigation(
    currentScreen: Screen,
    isAdmin: Boolean,
    pendingCount: Int,
    onNavigate: (Screen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("meshkat_bottom_bar")
    ) {
        NavigationBarItem(
            selected = currentScreen == Screen.DASHBOARD,
            onClick = { onNavigate(Screen.DASHBOARD) },
            icon = { Icon(Icons.Default.Dashboard, contentDescription = "داشبورد") },
            label = { Text("داشبورد", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                indicatorColor = MeshkatPrimary
            )
        )

        NavigationBarItem(
            selected = currentScreen == Screen.CHAT_LIST || currentScreen == Screen.CHAT_ROOM,
            onClick = { onNavigate(Screen.CHAT_LIST) },
            icon = { Icon(Icons.Default.Chat, contentDescription = "چت") },
            label = { Text("پیام‌رسان", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                indicatorColor = MeshkatPrimary
            )
        )

        NavigationBarItem(
            selected = currentScreen == Screen.REPORTS || currentScreen == Screen.NEW_REPORT,
            onClick = { onNavigate(Screen.REPORTS) },
            icon = { Icon(Icons.Default.Assignment, contentDescription = "گزارشات") },
            label = { Text("گزارشات", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                indicatorColor = MeshkatPrimary
            )
        )

        NavigationBarItem(
            selected = currentScreen == Screen.LEDGER,
            onClick = { onNavigate(Screen.LEDGER) },
            icon = { Icon(Icons.Default.AccountBalance, contentDescription = "امور مالی") },
            label = { Text("امور مالی", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = Color.White,
                indicatorColor = MeshkatPrimary
            )
        )

        if (isAdmin) {
            NavigationBarItem(
                selected = currentScreen in listOf(Screen.ADMIN_PANEL, Screen.ADMIN_USER_APPROVAL, Screen.ADMIN_PERMISSIONS, Screen.ADMIN_TICKER),
                onClick = { onNavigate(Screen.ADMIN_PANEL) },
                icon = {
                    if (pendingCount > 0) {
                        BadgedBox(
                            badge = {
                                Badge(containerColor = Color(0xFFC62828)) {
                                    Text(pendingCount.toString())
                                }
                            }
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = "مدیریت")
                        }
                    } else {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "مدیریت")
                    }
                },
                label = { Text("مدیریت", fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    indicatorColor = MeshkatPrimary
                )
            )
        }
    }
}
