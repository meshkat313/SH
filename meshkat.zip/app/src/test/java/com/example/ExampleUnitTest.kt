package com.example

import com.example.data.local.DatabaseMigrations
import com.example.data.local.LedgerEntryEntity
import com.example.data.local.NotificationEntity
import com.example.data.local.UserEntity
import com.example.data.remote.UsdRateData
import com.example.data.repository.FinancialSummary
import com.example.ui.screens.formatTomans
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testFinancialLedgerBalanceCalculation() {
        val totalBudget = 1_000_000_000L
        val totalExpenses = 400_000_000L
        val netBalance = totalBudget - totalExpenses
        val ratio = totalExpenses.toFloat() / totalBudget.toFloat()

        val summary = FinancialSummary(
            totalBudget = totalBudget,
            totalExpenses = totalExpenses,
            netBalance = netBalance,
            expenseRatio = ratio
        )

        assertEquals(600_000_000L, summary.netBalance)
        assertEquals(0.4f, summary.expenseRatio, 0.001f)
    }

    @Test
    fun testFormatTomansPersianDigits() {
        val formatted = formatTomans(94850L)
        assertTrue(formatted.contains("۹۴") || formatted.contains("850") || formatted.isNotEmpty())
    }

    @Test
    fun testUsdRateDataDefaultValues() {
        val data = UsdRateData()
        assertEquals(94850L, data.priceTomans)
        assertTrue(data.isPositive)
        assertEquals("alanchand.com/currencies-price/usd", data.source)
    }

    @Test
    fun testTwoFactorAuthenticationUserEntity() {
        val adminUser = UserEntity(
            username = "admin",
            password = "password",
            fullName = "مدیر ارشد",
            department = "مدیریت",
            role = "ADMIN",
            status = "APPROVED",
            isTwoFactorEnabled = true
        )
        assertTrue(adminUser.isTwoFactorEnabled)
        assertEquals("ADMIN", adminUser.role)
    }

    @Test
    fun testNotificationEntityCreation() {
        val notification = NotificationEntity(
            userId = 1L,
            title = "پیام چت جدید",
            message = "متن پیام امن",
            type = "CHAT"
        )
        assertEquals("CHAT", notification.type)
        assertFalse(notification.isRead)
    }

    @Test
    fun testDatabaseMigrationsDefinitions() {
        val migrations = DatabaseMigrations.ALL_MIGRATIONS
        assertEquals(2, migrations.size)
        assertEquals(1, migrations[0].startVersion)
        assertEquals(2, migrations[0].endVersion)
        assertEquals(2, migrations[1].startVersion)
        assertEquals(3, migrations[1].endVersion)
    }

    @Test
    fun testLedgerSchemaVersion3Fields() {
        val entry = LedgerEntryEntity(
            sectionType = "BUDGET_RECEIVED",
            title = "اعتبار مصوب",
            amountTomans = 50_000_000L,
            categoryOrSource = "خزانه",
            dateStr = "۱۴۰۳/۰۷/۲۵",
            referenceCode = "TRX-771"
        )
        assertEquals("۱۴۰۳", entry.fiscalYear)
        assertEquals("AUDITED", entry.auditStatus)
        assertEquals("TOMAN", entry.currencyUnit)
    }

    @Test
    fun testUserBiometricFields() {
        val user = UserEntity(
            username = "operator",
            password = "pwd",
            fullName = "اپراتور",
            department = "فنی",
            biometricEnabled = true,
            biometricToken = "bio_token_test_123"
        )
        assertTrue(user.biometricEnabled)
        assertEquals("bio_token_test_123", user.biometricToken)
    }
}
