-- =======================================================================
-- Meshkat (مشکات) Enterprise Database Migration Strategy Script
-- Version 1 -> Version 2 -> Version 3 Schema Evolution
-- Targets: SQLite / Room Database / PostgreSQL Compatibility
-- Ensures zero data loss for production Users and Ledger records.
-- =======================================================================

BEGIN TRANSACTION;

-- -----------------------------------------------------------------------
-- SECTION 1: Migration Version 1 -> Version 2
-- Enhances User Security (2FA, Presence, Push Notification Tokens)
-- Creates Notifications Log Table
-- -----------------------------------------------------------------------

-- 1.1 Add 2FA and Real-time Presence Columns to 'users' Table
ALTER TABLE users ADD COLUMN isTwoFactorEnabled INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN twoFactorSecret TEXT NOT NULL DEFAULT 'MSHK-2FA-SEC';
ALTER TABLE users ADD COLUMN isOnline INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN lastSeen INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN pushToken TEXT NOT NULL DEFAULT '';

-- 1.2 Create Centralized Push Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    userId INTEGER NOT NULL DEFAULT 0,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL, -- 'CHAT', 'ANNOUNCEMENT', 'REPORT_STATUS', 'SYSTEM'
    referenceId TEXT NOT NULL DEFAULT '',
    isRead INTEGER NOT NULL DEFAULT 0,
    createdAt INTEGER NOT NULL DEFAULT (strftime('%s','now') * 1000)
);

CREATE INDEX IF NOT EXISTS index_notifications_userId ON notifications (userId);
CREATE INDEX IF NOT EXISTS index_notifications_isRead ON notifications (isRead);

-- -----------------------------------------------------------------------
-- SECTION 2: Migration Version 2 -> Version 3
-- Adds Biometric Security Credentials to Users
-- Enhances Financial Ledger with Fiscal Governance & Auditing Attributes
-- Adds High-Performance Composite Indexes
-- -----------------------------------------------------------------------

-- 2.1 Add Biometric Authentication Capabilities to 'users' Table
ALTER TABLE users ADD COLUMN biometricEnabled INTEGER NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN biometricToken TEXT NOT NULL DEFAULT '';

-- 2.2 Add Fiscal Governance Columns to 'financial_ledger' Table
ALTER TABLE financial_ledger ADD COLUMN fiscalYear TEXT NOT NULL DEFAULT '۱۴۰۳';
ALTER TABLE financial_ledger ADD COLUMN auditStatus TEXT NOT NULL DEFAULT 'AUDITED';
ALTER TABLE financial_ledger ADD COLUMN currencyUnit TEXT NOT NULL DEFAULT 'TOMAN';

-- 2.3 Create Performance Optimizing Indexes for Rapid Analytics & Filtering
CREATE INDEX IF NOT EXISTS index_financial_ledger_sectionType ON financial_ledger (sectionType);
CREATE INDEX IF NOT EXISTS index_financial_ledger_dateStr ON financial_ledger (dateStr);
CREATE INDEX IF NOT EXISTS index_reports_userId ON reports (userId);
CREATE INDEX IF NOT EXISTS index_reports_status ON reports (status);

-- Verify Integrity
PRAGMA integrity_check;

COMMIT;

-- =======================================================================
-- End of Migration Script (Schema is now at Version 3)
-- =======================================================================
