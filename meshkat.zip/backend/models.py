import time
from sqlalchemy import Column, Integer, BigInteger, String, Boolean, Text, ForeignKey
from sqlalchemy.orm import relationship
from database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(64), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(128), nullable=False)
    department = Column(String(128), nullable=False)
    phone_number = Column(String(32), default="")
    role = Column(String(32), default="USER") # ADMIN, MANAGER, OPERATOR, USER
    status = Column(String(32), default="PENDING") # PENDING, APPROVED, REJECTED (Strict Pending Gate)

    can_access_ledger = Column(Boolean, default=False)
    can_access_reports = Column(Boolean, default=True)
    can_access_chat = Column(Boolean, default=True)
    can_access_announcements = Column(Boolean, default=True)
    can_access_admin = Column(Boolean, default=False)

    created_at = Column(BigInteger, default=lambda: int(time.time()))

    reports = relationship("Report", back_populates="user")
    messages = relationship("ChatMessage", back_populates="sender")

class Ticker(Base):
    __tablename__ = "ticker"

    id = Column(Integer, primary_key=True, default=1)
    message_text = Column(Text, nullable=False)
    is_active = Column(Boolean, default=True)
    speed_ms = Column(Integer, default=35)
    updated_at = Column(BigInteger, default=lambda: int(time.time()))
    updated_by = Column(String(128), default="مدیریت سیستم")

class Announcement(Base):
    __tablename__ = "announcements"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    content = Column(Text, nullable=False)
    tag = Column(String(64), default="اطلاعیه رسمی")
    is_pinned = Column(Boolean, default=True)
    author_name = Column(String(128), default="دبیرخانه مرکزی")
    created_at = Column(BigInteger, default=lambda: int(time.time()))

class Report(Base):
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(255), nullable=False)
    category = Column(String(64), nullable=False) # امنیتی, عملیاتی, فنی و زیرساخت, حراست, مالی
    priority = Column(String(32), default="متوسط") # بحرانی, بالا, متوسط, عادی
    description = Column(Text, nullable=False)
    attachment_name = Column(String(255), default="")
    status = Column(String(32), default="PENDING") # PENDING, INVESTIGATING, RESOLVED
    admin_note = Column(Text, default="")
    tracking_code = Column(String(32), nullable=False, unique=True)
    created_at = Column(BigInteger, default=lambda: int(time.time()))

    user = relationship("User", back_populates="reports")

class LedgerEntry(Base):
    __tablename__ = "financial_ledger"

    id = Column(Integer, primary_key=True, index=True)
    section_type = Column(String(32), nullable=False) # BUDGET_RECEIVED vs CORE_EXPENSE
    title = Column(String(255), nullable=False)
    amount_tomans = Column(BigInteger, nullable=False)
    category_or_source = Column(String(128), nullable=False)
    date_str = Column(String(32), nullable=False)
    reference_code = Column(String(64), nullable=False)
    payment_method = Column(String(64), default="حواله بانکی پایا")
    description = Column(Text, default="")
    created_at = Column(BigInteger, default=lambda: int(time.time()))

class ChatChannel(Base):
    __tablename__ = "chat_channels"

    id = Column(String(64), primary_key=True)
    title = Column(String(128), nullable=False)
    description = Column(String(255), default="")
    channel_type = Column(String(32), default="GROUP")
    created_at = Column(BigInteger, default=lambda: int(time.time()))

    messages = relationship("ChatMessage", back_populates="channel")

class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    channel_id = Column(String(64), ForeignKey("chat_channels.id"), nullable=False)
    sender_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    message_text = Column(Text, nullable=False)
    attachment_type = Column(String(32), default="NONE") # NONE, IMAGE, DOCUMENT, AUDIO
    attachment_name = Column(String(255), default="")
    timestamp = Column(BigInteger, default=lambda: int(time.time()))

    channel = relationship("ChatChannel", back_populates="messages")
    sender = relationship("User", back_populates="messages")
