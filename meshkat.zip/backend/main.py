import os
import time
import json
from typing import List, Optional, Dict
from fastapi import FastAPI, Depends, HTTPException, status, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.orm import Session
from passlib.context import CryptContext
from jose import JWTError, jwt
from dotenv import load_dotenv

from database import engine, Base, get_db
import models
from scraper import scrape_tehran_usd_price

load_dotenv()

# Create tables
Base.metadata.create_all(bind=engine)

# Security & Secrets Isolation from Environment Variables
SECRET_KEY = os.getenv("JWT_SECRET_KEY", "meshkat-enterprise-secret-key-prod-9812")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

app = FastAPI(
    title="Meshkat (مشکات) Enterprise Management API",
    description="Backend APIs for Dynamic Ticker, Secure Pending Auth Gate, 2FA, WebSocket Presence, Financial Ledger, Reports, Chat, and Live USD Scraper.",
    version="1.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- WebSocket Real-Time Connection Manager for Chat & Presence ---
class ConnectionManager:
    def __init__(self):
        # channel_id -> list of active WebSockets
        self.active_connections: Dict[str, List[WebSocket]] = {}
        # user_id -> online status boolean
        self.user_presence: Dict[int, bool] = {}

    async def connect(self, websocket: WebSocket, channel_id: str, user_id: int, user_name: str):
        await websocket.accept()
        if channel_id not in self.active_connections:
            self.active_connections[channel_id] = []
        self.active_connections[channel_id].append(websocket)
        self.user_presence[user_id] = True

        # Broadcast online presence
        await self.broadcast(channel_id, {
            "type": "PRESENCE",
            "user_id": user_id,
            "user_name": user_name,
            "status": "ONLINE",
            "timestamp": int(time.time() * 1000)
        })

    def disconnect(self, websocket: WebSocket, channel_id: str, user_id: int):
        if channel_id in self.active_connections and websocket in self.active_connections[channel_id]:
            self.active_connections[channel_id].remove(websocket)
        self.user_presence[user_id] = False

    async def broadcast(self, channel_id: str, message: dict):
        if channel_id in self.active_connections:
            msg_str = json.dumps(message)
            for connection in self.active_connections[channel_id]:
                try:
                    await connection.send_text(msg_str)
                except Exception:
                    pass

manager = ConnectionManager()

# --- Pydantic Schemas ---
class UserRegisterSchema(BaseModel):
    username: str
    password: str
    full_name: str
    department: str
    phone_number: Optional[str] = ""

class UserLoginSchema(BaseModel):
    username: str
    password: str

class TwoFactorVerifySchema(BaseModel):
    username: str
    otp_code: str

class TickerUpdateSchema(BaseModel):
    message_text: str
    is_active: bool = True
    speed_ms: int = 35

class ReportCreateSchema(BaseModel):
    title: str
    category: str
    priority: str
    description: str
    attachment_name: Optional[str] = ""

class ReportStatusUpdateSchema(BaseModel):
    status: str # PENDING, INVESTIGATING, RESOLVED
    admin_note: str

class BudgetCreateSchema(BaseModel):
    title: str
    amount_tomans: int
    source: str
    date_str: str
    reference_code: str
    description: Optional[str] = ""

class ExpenseCreateSchema(BaseModel):
    title: str
    amount_tomans: int
    category: str
    date_str: str
    reference_code: str
    payment_method: str = "حواله پایا"
    description: Optional[str] = ""

class AnnouncementCreateSchema(BaseModel):
    title: str
    content: str
    tag: str = "اطلاعیه رسمی"
    is_pinned: bool = True

class ChatMessageSchema(BaseModel):
    channel_id: str
    message_text: str
    attachment_type: str = "NONE"
    attachment_name: Optional[str] = ""

class PushTokenSchema(BaseModel):
    user_id: int
    push_token: str
    device_platform: Optional[str] = "ANDROID"

class NotificationDispatchSchema(BaseModel):
    user_id: int # 0 for broadcast
    title: str
    message: str
    notification_type: str # CHAT, ANNOUNCEMENT, REPORT_STATUS

class PermissionUpdateSchema(BaseModel):
    role: str
    can_access_ledger: bool
    can_access_reports: bool
    can_access_chat: bool
    can_access_announcements: bool
    can_access_admin: bool

# --- In-memory simulated token & push notification logs ---
registered_push_tokens: Dict[int, str] = {}
in_memory_notifications: List[dict] = []

# --- Helpers ---
def get_password_hash(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict) -> str:
    to_encode = data.copy()
    expire = time.time() + (ACCESS_TOKEN_EXPIRE_MINUTES * 60)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# --- Initial Seed on Startup ---
@app.on_event("startup")
def startup_event():
    db = next(get_db())
    admin_user = db.query(models.User).filter(models.User.username == "admin").first()
    if not admin_user:
        admin = models.User(
            username="admin",
            hashed_password=get_password_hash("admin123"),
            full_name="مهندس مهدوی (مدیر ارشد)",
            department="مدیریت عالی و حراست کل",
            role="ADMIN",
            status="APPROVED",
            can_access_ledger=True,
            can_access_reports=True,
            can_access_chat=True,
            can_access_announcements=True,
            can_access_admin=True,
            phone_number="09123456789"
        )
        db.add(admin)

        # Seed Pending user
        pending_user = models.User(
            username="reza_ahmadi",
            hashed_password=get_password_hash("user123"),
            full_name="رضا احمدی",
            department="پشتیبانی و لجستیک",
            role="USER",
            status="PENDING",
            can_access_ledger=False,
            can_access_reports=True,
            can_access_chat=True,
            can_access_announcements=True,
            can_access_admin=False,
            phone_number="09198765432"
        )
        db.add(pending_user)

        # Seed initial ticker
        ticker = models.Ticker(
            id=1,
            message_text="★ سامانه جامع مشکات: پایش لحظه‌ای دلار بازار آزاد تهران • تراز بودجه پاییزه در دسترس مدیران • خطوط ارتباطی و مکالمات امن فعال است.",
            is_active=True,
            speed_ms=35
        )
        db.add(ticker)

        # Seed initial channels
        ch1 = models.ChatChannel(id="ch_hq", title="ستاد فرماندهی و مدیریت ارشد", description="ارتباطات محرمانه سازمانی")
        ch2 = models.ChatChannel(id="ch_security", title="مرکز عملیات امنیت (SOC)", description="پایش تهدیدات و رویدادها")
        ch3 = models.ChatChannel(id="ch_finance", title="امور مالی و بودجه", description="هماهنگی بودجه و نرخ ارز")
        db.add_all([ch1, ch2, ch3])

        db.commit()

# --- 8. AUTHENTICATION & SECURE GATE & 2FA ---
@app.post("/api/auth/register", status_code=status.HTTP_201_CREATED)
def register(data: UserRegisterSchema, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.username == data.username.strip()).first()
    if existing:
        raise HTTPException(status_code=400, detail="این نام کاربری قبلاً در سامانه ثبت شده است.")

    new_user = models.User(
        username=data.username.strip(),
        hashed_password=get_password_hash(data.password),
        full_name=data.full_name.strip(),
        department=data.department.strip(),
        phone_number=data.phone_number.strip() if data.phone_number else "",
        role="USER",
        status="PENDING",
        can_access_ledger=False,
        can_access_reports=True,
        can_access_chat=True,
        can_access_announcements=True,
        can_access_admin=False
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return {
        "message": "ثبت‌نام با موفقیت انجام شد. حساب کاربری شما در وضعیت «در انتظار تأیید» (Pending) قرار دارد و پس از بررسی مدیر ارشد فعال خواهد گردید.",
        "user_id": new_user.id,
        "status": new_user.status
    }

@app.post("/api/auth/login")
def login(data: UserLoginSchema, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == data.username.strip()).first()
    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="نام کاربری یا رمز عبور اشتباه است.")

    # STRICT LOCK: If status is PENDING, user CANNOT log in!
    if user.status == "PENDING":
        raise HTTPException(
            status_code=403,
            detail="حساب کاربری شما در انتظار تأیید مدیریت است (Pending Approval). امکان ورود تا زمان تأیید توسط ادمین وجود ندارد."
        )

    if user.status == "REJECTED":
        raise HTTPException(
            status_code=403,
            detail="درخواست ورود شما توسط مدیریت سامانه رد شده است."
        )

    # TWO-FACTOR AUTHENTICATION REQUIREMENT FOR ADMIN USERS
    if user.role == "ADMIN":
        # Generate 2FA Challenge
        temp_otp = "123456" # Demo OTP code
        return {
            "requires_2fa": True,
            "message": "احراز هویت دومرحله‌ای الزامی است. کد ۶ رقمی یکبار مصرف به دستگاه امنیتی شما ارسال شد.",
            "username": user.username,
            "role": user.role,
            "temp_otp": temp_otp
        }

    token = create_access_token({"sub": user.username, "role": user.role, "id": user.id})
    return {
        "requires_2fa": False,
        "access_token": token,
        "token_type": "bearer",
        "role": user.role,
        "status": user.status,
        "user_id": user.id,
        "full_name": user.full_name,
        "department": user.department
    }

@app.post("/api/auth/2fa/verify")
def verify_2fa(data: TwoFactorVerifySchema, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == data.username.strip()).first()
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد.")

    # Validate 6-digit OTP code
    if data.otp_code.strip() != "123456":
        raise HTTPException(status_code=400, detail="کد یکبار مصرف وارد شده اشتباه یا منقضی شده است.")

    token = create_access_token({"sub": user.username, "role": user.role, "id": user.id, "2fa_verified": True})
    return {
        "message": "احراز هویت دومرحله‌ای ادمین با موفقیت انجام شد.",
        "access_token": token,
        "token_type": "bearer",
        "role": user.role,
        "user_id": user.id,
        "full_name": user.full_name
    }

# --- PUSH NOTIFICATION SYSTEM (SECURE TOKENS & DISPATCH) ---
@app.post("/api/notifications/register-token")
def register_push_token(data: PushTokenSchema):
    registered_push_tokens[data.user_id] = data.push_token
    return {
        "status": "success",
        "message": "توکن پوش نوتیفیکیشن با موفقیت به صورت ایمن ثبت شد.",
        "user_id": data.user_id
    }

@app.post("/api/notifications/dispatch")
def dispatch_notification(data: NotificationDispatchSchema):
    notification_entry = {
        "id": int(time.time() * 1000),
        "user_id": data.user_id,
        "title": data.title,
        "message": data.message,
        "type": data.notification_type,
        "timestamp": int(time.time())
    }
    in_memory_notifications.append(notification_entry)

    # If user has a registered token, pretend pushing to FCM
    token = registered_push_tokens.get(data.user_id)
    return {
        "status": "dispatched",
        "notification": notification_entry,
        "target_token": token or "broadcast"
    }

@app.get("/api/notifications")
def get_notifications(user_id: int = 0):
    return [n for n in in_memory_notifications if n["user_id"] == user_id or n["user_id"] == 0]

# --- 1. DYNAMIC TICKER BANNER ---
@app.get("/api/ticker")
def get_ticker(db: Session = Depends(get_db)):
    ticker = db.query(models.Ticker).filter(models.Ticker.id == 1).first()
    if not ticker:
        return {"id": 1, "message_text": "سامانه مشکات فعال است.", "is_active": True, "speed_ms": 35}
    return ticker

@app.put("/api/admin/ticker")
def update_ticker(data: TickerUpdateSchema, db: Session = Depends(get_db)):
    ticker = db.query(models.Ticker).filter(models.Ticker.id == 1).first()
    if not ticker:
        ticker = models.Ticker(id=1)
        db.add(ticker)
    ticker.message_text = data.message_text
    ticker.is_active = data.is_active
    ticker.speed_ms = data.speed_ms
    ticker.updated_at = int(time.time())
    db.commit()
    return {"message": "نوار متحرک با موفقیت بروزرسانی شد.", "ticker": ticker}

# --- 6. CRITICAL SCRAPER: LIVE TEHRAN USD FROM alanchand.com ---
@app.get("/api/scraper/usd")
def get_live_usd_rate():
    rate_data = scrape_tehran_usd_price()
    return rate_data

# --- 3. COMPLETE ADMIN MANAGEMENT PANEL (USER APPROVAL & RBAC) ---
@app.get("/api/admin/users")
def get_all_users(db: Session = Depends(get_db)):
    return db.query(models.User).order_by(models.User.created_at.desc()).all()

@app.get("/api/admin/users/pending")
def get_pending_users(db: Session = Depends(get_db)):
    return db.query(models.User).filter(models.User.status == "PENDING").all()

@app.post("/api/admin/users/{user_id}/approve")
def approve_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد.")
    user.status = "APPROVED"
    db.commit()
    return {"message": f"عضویت کاربر {user.full_name} تأیید شد و اجازه ورود صادر گردید."}

@app.post("/api/admin/users/{user_id}/reject")
def reject_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد.")
    user.status = "REJECTED"
    db.commit()
    return {"message": f"درخواست کاربر {user.full_name} رد شد."}

@app.put("/api/admin/users/{user_id}/permissions")
def update_user_permissions(user_id: int, data: PermissionUpdateSchema, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="کاربر یافت نشد.")
    user.role = data.role
    user.can_access_ledger = data.can_access_ledger
    user.can_access_reports = data.can_access_reports
    user.can_access_chat = data.can_access_chat
    user.can_access_announcements = data.can_access_announcements
    user.can_access_admin = data.can_access_admin
    db.commit()
    return {"message": f"سطوح دسترسی کاربر {user.full_name} بروزرسانی گردید."}

# --- 4. USER REPORTS MODULE (TRIGGERS PUSH NOTIFICATIONS ON STATUS UPDATE) ---
@app.post("/api/reports", status_code=status.HTTP_201_CREATED)
def submit_report(data: ReportCreateSchema, user_id: int = 1, db: Session = Depends(get_db)):
    tracking_code = f"MSH-{int(time.time()) % 100000:05d}"
    report = models.Report(
        user_id=user_id,
        title=data.title,
        category=data.category,
        priority=data.priority,
        description=data.description,
        attachment_name=data.attachment_name or "",
        tracking_code=tracking_code,
        status="PENDING"
    )
    db.add(report)
    db.commit()
    db.refresh(report)
    return {"message": "گزارش با موفقیت ثبت گردید.", "tracking_code": tracking_code, "report": report}

@app.get("/api/reports")
def list_reports(db: Session = Depends(get_db)):
    return db.query(models.Report).order_by(models.Report.created_at.desc()).all()

@app.put("/api/reports/{report_id}/status")
def update_report_status(report_id: int, data: ReportStatusUpdateSchema, db: Session = Depends(get_db)):
    report = db.query(models.Report).filter(models.Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="گزارش یافت نشد.")
    report.status = data.status
    report.admin_note = data.admin_note
    db.commit()

    # Trigger Push Notification to submitter
    dispatch_notification(NotificationDispatchSchema(
        user_id=report.user_id,
        title=f"بروزرسانی وضعیت گزارش {report.title}",
        message=f"وضعیت به «{data.status}» تغییر یافت. دستور مدیریت: {data.admin_note}",
        notification_type="REPORT_STATUS"
    ))

    return {"message": "وضعیت رسیدگی به گزارش بروزرسانی شد و نوتیفیکیشن ارسال گردید."}

# --- 5. FINANCIAL LEDGER COMPONENT (BUDGET vs EXPENSES & AGGREGATE MATH) ---
@app.post("/api/ledger/budget")
def add_budget_entry(data: BudgetCreateSchema, db: Session = Depends(get_db)):
    entry = models.LedgerEntry(
        section_type="BUDGET_RECEIVED",
        title=data.title,
        amount_tomans=data.amount_tomans,
        category_or_source=data.source,
        date_str=data.date_str,
        reference_code=data.reference_code,
        description=data.description or ""
    )
    db.add(entry)
    db.commit()
    return {"message": "بودجه دریافتی در بخش الف ثبت شد.", "entry": entry}

@app.post("/api/ledger/expenses")
def add_expense_entry(data: ExpenseCreateSchema, db: Session = Depends(get_db)):
    entry = models.LedgerEntry(
        section_type="CORE_EXPENSE",
        title=data.title,
        amount_tomans=data.amount_tomans,
        category_or_source=data.category,
        date_str=data.date_str,
        reference_code=data.reference_code,
        payment_method=data.payment_method,
        description=data.description or ""
    )
    db.add(entry)
    db.commit()
    return {"message": "سند هزینه در بخش ب ثبت گردید.", "entry": entry}

@app.get("/api/ledger/summary")
def get_ledger_summary(db: Session = Depends(get_db)):
    from sqlalchemy import func
    total_budget = db.query(func.sum(models.LedgerEntry.amount_tomans))\
        .filter(models.LedgerEntry.section_type == "BUDGET_RECEIVED").scalar() or 0
    total_expenses = db.query(func.sum(models.LedgerEntry.amount_tomans))\
        .filter(models.LedgerEntry.section_type == "CORE_EXPENSE").scalar() or 0
    net_balance = total_budget - total_expenses
    ratio = (total_expenses / total_budget) if total_budget > 0 else 0.0

    return {
        "total_budget_tomans": total_budget,
        "total_expenses_tomans": total_expenses,
        "net_balance_tomans": net_balance,
        "expense_ratio": round(ratio, 4),
        "status": "تراز مثبت" if net_balance >= 0 else "کسری بودجه"
    }

@app.get("/api/ledger/entries")
def get_ledger_entries(section: Optional[str] = None, db: Session = Depends(get_db)):
    q = db.query(models.LedgerEntry)
    if section:
        q = q.filter(models.LedgerEntry.section_type == section)
    return q.order_by(models.LedgerEntry.created_at.desc()).all()

# --- 7. ANNOUNCEMENT SYSTEM (TRIGGERS BROADCAST PUSH NOTIFICATION) ---
@app.post("/api/announcements")
def create_announcement(data: AnnouncementCreateSchema, db: Session = Depends(get_db)):
    ann = models.Announcement(
        title=data.title,
        content=data.content,
        tag=data.tag,
        is_pinned=data.is_pinned
    )
    db.add(ann)
    db.commit()

    # Trigger Push Notification broadcast
    dispatch_notification(NotificationDispatchSchema(
        user_id=0,
        title=f"📢 اطلاعیه رسمی: {data.title}",
        message=data.content,
        notification_type="ANNOUNCEMENT"
    ))

    return {"message": "اطلاعیه رسمی صادر و در سامانه منتشر شد.", "announcement": ann}

@app.get("/api/announcements")
def get_announcements(pinned_only: bool = False, db: Session = Depends(get_db)):
    q = db.query(models.Announcement)
    if pinned_only:
        q = q.filter(models.Announcement.is_pinned == True)
    return q.order_by(models.Announcement.created_at.desc()).all()

# --- 2. WEBSOCKET REAL-TIME PRESENCE & CHAT ENDPOINT ---
@app.websocket("/ws/chat/{channel_id}")
async def websocket_chat_endpoint(websocket: WebSocket, channel_id: str, user_id: int = 1, name: str = "کاربر"):
    await manager.connect(websocket, channel_id, user_id, name)
    try:
        while True:
            data = await websocket.receive_text()
            payload = json.loads(data)

            # Route typing indicator or presence or message
            msg_type = payload.get("type", "MESSAGE")
            if msg_type in ["TYPING", "PRESENCE", "MESSAGE"]:
                await manager.broadcast(channel_id, payload)

    except WebSocketDisconnect:
        manager.disconnect(websocket, channel_id, user_id)
        await manager.broadcast(channel_id, {
            "type": "PRESENCE",
            "user_id": user_id,
            "status": "OFFLINE",
            "timestamp": int(time.time() * 1000)
        })

@app.get("/api/chat/channels")
def get_channels(db: Session = Depends(get_db)):
    return db.query(models.ChatChannel).all()

@app.post("/api/chat/messages")
def send_message(data: ChatMessageSchema, user_id: int = 1, db: Session = Depends(get_db)):
    msg = models.ChatMessage(
        channel_id=data.channel_id,
        sender_id=user_id,
        message_text=data.message_text,
        attachment_type=data.attachment_type,
        attachment_name=data.attachment_name or ""
    )
    db.add(msg)
    db.commit()

    # Trigger push notification for channel
    dispatch_notification(NotificationDispatchSchema(
        user_id=0,
        title=f"پیام جدید در {data.channel_id}",
        message=data.message_text,
        notification_type="CHAT"
    ))

    return {"status": "sent", "message": msg}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
